@echo off
setlocal
cd /d "%~dp0.."

echo [RedCord 0.7.2] building installer...

if not exist ".venv\Scripts\activate.bat" (
    echo [Installer] .venv not found.
    pause
    exit /b 1
)

call ".venv\Scripts\activate.bat"

echo.
echo [Installer] Building RedCord...
call scripts\build_exe.bat
if errorlevel 1 exit /b 1

echo.
echo [Installer] Checking build output...
if not exist "redcord_build\redcord\RedCord.exe" (
    echo [Installer] Missing redcord_build\redcord\RedCord.exe
    pause
    exit /b 1
)

where ISCC.exe >nul 2>nul
if errorlevel 1 (
    if exist "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" (
        set "ISCC=C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
    ) else if exist "C:\Program Files\Inno Setup 6\ISCC.exe" (
        set "ISCC=C:\Program Files\Inno Setup 6\ISCC.exe"
    ) else (
        echo [Installer] Inno Setup 6 not found.
        echo Install Inno Setup 6 or add ISCC.exe to PATH.
        pause
        exit /b 1
    )
) else (
    set "ISCC=ISCC.exe"
)

if exist "installer_output" rmdir /s /q "installer_output"
"%ISCC%" installer\RedCord_Installer.iss

if errorlevel 1 (
    echo [Installer] Build failed.
    pause
    exit /b 1
)

echo.
echo [Installer] Done:
echo   installer_output\RedCord_Setup_0_7_2.exe
pause
endlocal
