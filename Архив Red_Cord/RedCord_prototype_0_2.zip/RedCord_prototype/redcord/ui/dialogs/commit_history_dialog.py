from __future__ import annotations

import uuid

from PyQt6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
)

from redcord.db.models import Commit
from redcord.services.commit_service import CommitService


class CommitHistoryDialog(QDialog):
    def __init__(self, document_id: uuid.UUID, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("История коммитов")
        self.resize(850, 550)
        self.document_id = document_id
        self.commit_service = CommitService()
        self.commits: dict[str, Commit] = {}

        self.list_widget = QListWidget()
        self.snapshot_view = QTextEdit()
        self.snapshot_view.setReadOnly(True)

        self.view_btn = QPushButton("Просмотр")
        self.rollback_btn = QPushButton("Откатить")
        self.close_btn = QPushButton("Закрыть")

        self.view_btn.clicked.connect(self.preview_selected)
        self.rollback_btn.clicked.connect(self.rollback_selected)
        self.close_btn.clicked.connect(self.close)
        self.list_widget.itemDoubleClicked.connect(lambda _: self.preview_selected())

        buttons = QHBoxLayout()
        buttons.addWidget(self.view_btn)
        buttons.addWidget(self.rollback_btn)
        buttons.addStretch(1)
        buttons.addWidget(self.close_btn)

        layout = QVBoxLayout(self)
        content = QHBoxLayout()
        content.addWidget(self.list_widget, 1)
        content.addWidget(self.snapshot_view, 2)
        layout.addLayout(content)
        layout.addLayout(buttons)
        self.reload()

    def reload(self) -> None:
        self.list_widget.clear()
        self.commits.clear()
        for commit in self.commit_service.list_commits(self.document_id):
            item = QListWidgetItem(f"{commit.created_at:%Y-%m-%d %H:%M:%S} — {commit.message}")
            item.setData(256, str(commit.id))
            self.list_widget.addItem(item)
            self.commits[str(commit.id)] = commit

    def selected_commit(self) -> Commit | None:
        item = self.list_widget.currentItem()
        if item is None:
            return None
        return self.commits.get(item.data(256))

    def preview_selected(self) -> None:
        commit = self.selected_commit()
        if commit is None:
            return
        self.snapshot_view.setPlainText(commit.content_snapshot)

    def rollback_selected(self) -> None:
        commit = self.selected_commit()
        if commit is None:
            return
        answer = QMessageBox.question(
            self,
            "Откат к коммиту",
            f"Откатить документ к коммиту:\n{commit.message}?",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            self.commit_service.rollback_to_commit(commit.id)
            QMessageBox.information(self, "Откат", "Документ откатан. Создан rollback-коммит.")
            self.reload()
            self.accept()
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Ошибка отката", str(exc))
