@echo off
setlocal
cd /d "%~dp0.."

echo [BlueCord v1 / BoC] building Windows EXE...

if not exist ".venv\Scripts\activate.bat" (
    echo [BlueCord] .venv not found.
    pause
    exit /b 1
)

call ".venv\Scripts\activate.bat"
python -m pip install -r requirements.txt
pyinstaller --noconfirm --clean --distpath bluecord_build bluecord.spec

if errorlevel 1 (
    echo [BlueCord] Build failed.
    pause
    exit /b 1
)

echo Output: bluecord_build\bluecord\BlueCord.exe
pause
endlocal
