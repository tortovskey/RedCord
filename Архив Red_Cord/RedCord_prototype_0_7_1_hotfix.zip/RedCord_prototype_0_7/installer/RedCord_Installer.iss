#define MyAppName "RedCord"
#define MyAppVersion "0.7.1"
#define MyAppPublisher "RedCord Project"
#define MyAppExeName "RedCord.exe"

[Setup]
AppId={{2A9E99CF-8E11-4D42-9B5B-0E0C0D070000}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\RedCord
DefaultGroupName=RedCord
AllowNoIcons=yes
OutputDir=..\installer_output
OutputBaseFilename=RedCord_Setup_0_7_1
SetupIconFile=..\redcord\assets\redcord_icon.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayIcon={app}\RedCord.exe

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; GroupDescription: "Ярлыки:"; Flags: unchecked
Name: "bluecorddesktop"; Description: "Создать ярлык BlueCord на рабочем столе"; GroupDescription: "Ярлыки:"; Flags: unchecked; Components: bluecord

[Components]
Name: "redcord"; Description: "RedCord Writer Desktop"; Types: full compact custom; Flags: fixed
Name: "bluecord"; Description: "BlueCord v1 standalone drawing app"; Types: full custom

[Files]
Source: "..\redcord_build\redcord\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs; Components: redcord
Source: "..\bluecord_build\BlueCord\*"; DestDir: "{app}\BlueCord"; Flags: ignoreversion recursesubdirs createallsubdirs skipifsourcedoesntexist; Components: bluecord
Source: "..\.env.example"; DestDir: "{app}"; Flags: ignoreversion onlyifdoesntexist; Components: redcord

[Dirs]
Name: "{app}\data"
Name: "{app}\commits"
Name: "{app}\data\backups"
Name: "{app}\data\update_backups"

[Icons]
Name: "{group}\RedCord"; Filename: "{app}\RedCord.exe"; WorkingDir: "{app}"; IconFilename: "{app}\redcord\assets\redcord_icon.ico"; Components: redcord
Name: "{group}\BlueCord"; Filename: "{app}\BlueCord\BlueCord.exe"; WorkingDir: "{app}\BlueCord"; IconFilename: "{app}\BlueCord\bluecord\assets\bluecord_icon.ico"; Components: bluecord
Name: "{group}\Удалить RedCord"; Filename: "{uninstallexe}"
Name: "{autodesktop}\RedCord"; Filename: "{app}\RedCord.exe"; WorkingDir: "{app}"; Tasks: desktopicon; Components: redcord
Name: "{autodesktop}\BlueCord"; Filename: "{app}\BlueCord\BlueCord.exe"; WorkingDir: "{app}\BlueCord"; Tasks: bluecorddesktop; Components: bluecord

[Run]
Filename: "{app}\RedCord.exe"; Description: "Запустить RedCord"; Flags: nowait postinstall skipifsilent; Components: redcord

[UninstallDelete]
; User data intentionally not deleted: data/, commits/, .env stay in place.
Type: filesandordirs; Name: "{app}\__pycache__"

[Code]
function InitializeSetup(): Boolean;
begin
  Result := True;
end;
