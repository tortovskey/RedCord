from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from redcord.app.config import get_settings


@dataclass
class UpdateResult:
    copied_files: int
    skipped_files: int
    backup_dir: Path
    message: str
    mode: str
    staged_dir: Path | None = None
    apply_script: Path | None = None
    detected_version: str = "unknown"


class UpdateErrorForUser(RuntimeError):
    """Safe update error to show in UI."""


class UpdateService:
    """Safe archive updater that preserves user data.

    Development/source mode:
        files are copied directly into the project folder.

    EXE/one-folder mode:
        update is staged into data/pending_update and an apply_update.bat script is generated.
        The script waits until RedCord.exe closes, copies the staged files, preserves data/commits/.env,
        and then starts RedCord again.
    """

    SKIP_DIR_NAMES = {
        ".venv",
        "venv",
        "__pycache__",
        ".git",
        ".idea",
        ".pytest_cache",
        "data",
        "commits",
        "redcord_build",
        "build",
        "dist",
        "update_backups",
        "pending_update",
    }
    SKIP_FILE_NAMES = {
        ".env",
        "redcord.db",
        "settings.json",
        "accounts.json",
        "branches.json",
        "redcord.log",
    }
    CODE_MARKERS = {
        "redcord",
        "scripts",
        "requirements.txt",
        "pyproject.toml",
        "README.md",
        "redcord.spec",
        "bluecord.spec",
        "alembic.ini",
    }

    def __init__(self) -> None:
        self.settings = get_settings()

    def apply_update_from_archive(self, archive_path: str | Path) -> UpdateResult:
        archive = Path(archive_path)
        if not archive.exists() or archive.suffix.lower() != ".zip":
            raise UpdateErrorForUser("Выберите ZIP-архив новой версии RedCord.")

        target_dir = self.settings.app_dir
        if not target_dir.exists():
            raise UpdateErrorForUser("Папка приложения не найдена.")

        self.settings.data_dir.mkdir(parents=True, exist_ok=True)
        self.settings.commit_dir.mkdir(parents=True, exist_ok=True)

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            try:
                with zipfile.ZipFile(archive, "r") as zip_file:
                    zip_file.extractall(tmp_path)
            except Exception as exc:  # noqa: BLE001
                raise UpdateErrorForUser(f"Не удалось распаковать архив: {exc}") from exc

            source_root = self._find_source_root(tmp_path)
            detected_version = self._detect_version(source_root)
            target_has_exe = (target_dir / "RedCord.exe").exists()
            source_has_exe = (source_root / "RedCord.exe").exists()
            if target_has_exe and not source_has_exe:
                raise UpdateErrorForUser(
                    "Вы запускаете RedCord как EXE, но в выбранном архиве нет RedCord.exe. "
                    "Для обновления EXE нужен архив уже собранной версии, например папка "
                    "redcord_build/redcord, упакованная в ZIP. Архив с исходным кодом подходит "
                    "только для запуска через python -m redcord.app.main."
                )

            backup_dir = self._backup_current(target_dir)

            if self._needs_external_apply(target_dir):
                staged_dir = self._stage_update(source_root, detected_version)
                apply_script = self._write_apply_script(staged_dir, target_dir, backup_dir)
                self._write_manifest(
                    staged_dir=staged_dir,
                    source_root=source_root,
                    backup_dir=backup_dir,
                    detected_version=detected_version,
                    mode="staged",
                )
                return UpdateResult(
                    copied_files=0,
                    skipped_files=0,
                    backup_dir=backup_dir,
                    staged_dir=staged_dir,
                    apply_script=apply_script,
                    detected_version=detected_version,
                    mode="staged",
                    message=(
                        f"Обновление {detected_version} подготовлено.\n\n"
                        "RedCord запущен как EXE, поэтому файлы приложения лучше заменить после закрытия.\n"
                        f"Папка обновления: {staged_dir}\n"
                        f"Скрипт применения: {apply_script}\n\n"
                        "Нажмите «Запустить применитель» или закройте RedCord и запустите apply_update.bat вручную."
                    ),
                )

            copied, skipped = self._copy_update(source_root, target_dir)
            self._write_manifest(
                staged_dir=self.settings.data_dir,
                source_root=source_root,
                backup_dir=backup_dir,
                detected_version=detected_version,
                mode="direct",
                copied_files=copied,
                skipped_files=skipped,
            )

        return UpdateResult(
            copied_files=copied,
            skipped_files=skipped,
            backup_dir=backup_dir,
            detected_version=detected_version,
            mode="direct",
            message=(
                f"Обновление {detected_version} установлено.\n"
                f"Скопировано файлов: {copied}.\n"
                f"Пропущено пользовательских/защищённых файлов: {skipped}.\n\n"
                "Перезапустите RedCord."
            ),
        )

    def launch_apply_script(self, script_path: str | Path) -> None:
        script = Path(script_path)
        if not script.exists():
            raise UpdateErrorForUser("Скрипт применения обновления не найден.")
        subprocess.Popen(["cmd", "/c", "start", "", str(script)], cwd=str(script.parent), shell=False)

    def _needs_external_apply(self, target_dir: Path) -> bool:
        return bool(getattr(sys, "frozen", False)) or (target_dir / "RedCord.exe").exists()

    def _find_source_root(self, extracted_root: Path) -> Path:
        candidates: list[Path] = []

        for directory in [extracted_root, *[p for p in extracted_root.rglob("*") if p.is_dir()]]:
            names = {p.name for p in directory.iterdir()} if directory.exists() else set()
            if "redcord" in names and ((directory / "redcord").is_dir()):
                candidates.append(directory)
            if "RedCord.exe" in names:
                candidates.append(directory)

        if not candidates:
            raise UpdateErrorForUser(
                "В архиве не найдена структура RedCord. Ожидалась папка redcord/ или RedCord.exe."
            )

        def score(path: Path) -> int:
            names = {p.name for p in path.iterdir()}
            return len(names & self.CODE_MARKERS) + (3 if "RedCord.exe" in names else 0)

        return sorted(candidates, key=score, reverse=True)[0]

    def _detect_version(self, source_root: Path) -> str:
        init_file = source_root / "redcord" / "__init__.py"
        if init_file.exists():
            text = init_file.read_text(encoding="utf-8", errors="ignore")
            for line in text.splitlines():
                if "__version__" in line and "=" in line:
                    return line.split("=", 1)[1].strip().strip('"').strip("'")
        return "unknown"

    def _backup_current(self, target_dir: Path) -> Path:
        backup_root = self.settings.data_dir / "update_backups"
        backup_dir = backup_root / datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        backup_dir.mkdir(parents=True, exist_ok=True)

        names_to_backup = [
            "redcord",
            "scripts",
            "requirements.txt",
            "pyproject.toml",
            "README.md",
            "redcord.spec",
            "bluecord.spec",
            "alembic.ini",
            "RedCord.exe",
            "BlueCord.exe",
        ]
        for name in names_to_backup:
            src = target_dir / name
            if not src.exists():
                continue
            dst = backup_dir / name
            try:
                if src.is_dir():
                    shutil.copytree(
                        src,
                        dst,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"),
                    )
                else:
                    shutil.copy2(src, dst)
            except PermissionError:
                continue
            except OSError:
                continue

        return backup_dir

    def _stage_update(self, source_root: Path, detected_version: str) -> Path:
        staging_root = self.settings.data_dir / "pending_update"
        if staging_root.exists():
            shutil.rmtree(staging_root, ignore_errors=True)
        staged_dir = staging_root / f"redcord_{detected_version}_{datetime.now():%Y-%m-%d_%H-%M-%S}"
        staged_dir.mkdir(parents=True, exist_ok=True)

        copied, skipped = self._copy_update(source_root, staged_dir)
        (staged_dir / "_stage_info.json").write_text(
            json.dumps(
                {
                    "version": detected_version,
                    "created_at": datetime.now().isoformat(timespec="seconds"),
                    "copied_files": copied,
                    "skipped_files": skipped,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        return staged_dir

    def _write_apply_script(self, staged_dir: Path, target_dir: Path, backup_dir: Path) -> Path:
        script = self.settings.data_dir / "pending_update" / "apply_update.bat"
        script.parent.mkdir(parents=True, exist_ok=True)

        redcord_exe = target_dir / "RedCord.exe"
        bluecord_exe = target_dir / "BlueCord.exe"

        script.write_text(
            f"""@echo off
setlocal
title RedCord Update Applicator

echo [RedCord] Applying staged update...
echo Target: {target_dir}
echo Staged: {staged_dir}
echo Backup: {backup_dir}
echo.

echo Waiting for RedCord.exe to close...
:wait_loop
tasklist /FI "IMAGENAME eq RedCord.exe" | find /I "RedCord.exe" >nul
if not errorlevel 1 (
    timeout /t 2 /nobreak >nul
    goto wait_loop
)

echo Copying files...
robocopy "{staged_dir}" "{target_dir}" /E /XD data commits update_backups pending_update __pycache__ .git .venv venv build dist redcord_build /XF .env redcord.db settings.json accounts.json branches.json redcord.log *.pyc *.pyo _stage_info.json
set RC=%ERRORLEVEL%
if %RC% GEQ 8 (
    echo.
    echo [RedCord] Update failed. Robocopy code: %RC%
    echo Backup is here: {backup_dir}
    pause
    exit /b %RC%
)

echo.
echo [RedCord] Update applied.
echo User data was preserved.
echo.

if exist "{redcord_exe}" (
    echo Starting RedCord...
    start "" "{redcord_exe}"
) else (
    echo RedCord.exe was not found. Start the app manually.
)

endlocal
""",
            encoding="utf-8",
        )
        return script

    def _write_manifest(
        self,
        staged_dir: Path,
        source_root: Path,
        backup_dir: Path,
        detected_version: str,
        mode: str,
        copied_files: int = 0,
        skipped_files: int = 0,
    ) -> None:
        manifest_path = self.settings.data_dir / "last_update.json"
        manifest_path.write_text(
            json.dumps(
                {
                    "version": detected_version,
                    "mode": mode,
                    "created_at": datetime.now().isoformat(timespec="seconds"),
                    "source_root": str(source_root),
                    "staged_dir": str(staged_dir),
                    "backup_dir": str(backup_dir),
                    "copied_files": copied_files,
                    "skipped_files": skipped_files,
                    "preserved": [
                        "data/",
                        "commits/",
                        ".env",
                        "redcord.db",
                        "settings.json",
                        "accounts.json",
                        "branches.json",
                        "redcord.log",
                    ],
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

    def _should_skip(self, rel_path: Path) -> bool:
        if any(part in self.SKIP_DIR_NAMES for part in rel_path.parts):
            return True
        if rel_path.name in self.SKIP_FILE_NAMES:
            return True
        if rel_path.suffix in {".pyc", ".pyo"}:
            return True
        return False

    def _copy_update(self, source_root: Path, target_dir: Path) -> tuple[int, int]:
        copied = 0
        skipped = 0
        for src in source_root.rglob("*"):
            if not src.is_file():
                continue
            rel = src.relative_to(source_root)
            if self._should_skip(rel):
                skipped += 1
                continue
            dst = target_dir / rel
            try:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
                copied += 1
            except PermissionError:
                skipped += 1
            except OSError:
                skipped += 1
        return copied, skipped
