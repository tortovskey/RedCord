from __future__ import annotations

from pathlib import Path

from PyQt6.QtCore import QPoint, QRect, Qt
from PyQt6.QtGui import QColor, QImage, QMouseEvent, QPainter, QPen
from PyQt6.QtWidgets import (
    QColorDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QSlider,
    QVBoxLayout,
    QWidget,
)


class LiteCanvas(QWidget):
    """Very stable embedded BlueCord Lite canvas for RedCord."""

    def __init__(self) -> None:
        super().__init__()
        self.setMinimumSize(760, 480)
        self.image = QImage(1280, 720, QImage.Format.Format_ARGB32)
        self.image.fill(QColor("white"))
        self.color = QColor("#179cff")
        self.brush_size = 6
        self.is_eraser = False
        self.drawing = False
        self.last_point = QPoint()

    def set_color(self, color: QColor) -> None:
        self.color = color
        self.is_eraser = False

    def set_size(self, value: int) -> None:
        self.brush_size = max(1, value)

    def set_eraser(self, enabled: bool) -> None:
        self.is_eraser = enabled

    def clear(self) -> None:
        self.image.fill(QColor("white"))
        self.update()

    def open_image(self, path: str | Path) -> bool:
        loaded = QImage(str(path))
        if loaded.isNull():
            return False
        self.image = loaded.convertToFormat(QImage.Format.Format_ARGB32)
        self.update()
        return True

    def save_image(self, path: str | Path) -> bool:
        suffix = Path(path).suffix.lower()
        fmt = "PNG"
        if suffix in {".jpg", ".jpeg"}:
            fmt = "JPG"
        elif suffix == ".bmp":
            fmt = "BMP"
        return self.image.save(str(path), fmt)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.fillRect(QRect(0, 0, self.width(), self.height()), QColor("#071522"))
        scaled = self.image.scaled(
            self.size(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        x = (self.width() - scaled.width()) // 2
        y = (self.height() - scaled.height()) // 2
        painter.fillRect(QRect(x - 8, y - 8, scaled.width() + 16, scaled.height() + 16), QColor("#10263a"))
        painter.drawImage(x, y, scaled)

    def _map_to_image(self, point: QPoint) -> QPoint:
        scaled = self.image.scaled(
            self.size(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        x_offset = (self.width() - scaled.width()) // 2
        y_offset = (self.height() - scaled.height()) // 2
        x = int((point.x() - x_offset) * self.image.width() / max(1, scaled.width()))
        y = int((point.y() - y_offset) * self.image.height() / max(1, scaled.height()))
        return QPoint(max(0, min(self.image.width() - 1, x)), max(0, min(self.image.height() - 1, y)))

    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() != Qt.MouseButton.LeftButton:
            return
        self.drawing = True
        self.last_point = self._map_to_image(event.position().toPoint())

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if not self.drawing:
            return
        current = self._map_to_image(event.position().toPoint())
        painter = QPainter(self.image)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        color = QColor("white") if self.is_eraser else self.color
        pen = QPen(color, self.brush_size, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
        painter.setPen(pen)
        painter.drawLine(self.last_point, current)
        painter.end()
        self.last_point = current
        self.update()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        self.drawing = False


class BlueCordLiteWidget(QWidget):
    """BlueCord Lite embedded into RedCord: stable sketchpad, not the full standalone app."""

    def __init__(self) -> None:
        super().__init__()
        self.canvas = LiteCanvas()

        title = QLabel("BlueCord Lite · ReC встроенная версия")
        self.color_btn = QPushButton("Цвет")
        self.eraser_btn = QPushButton("Ластик")
        self.clear_btn = QPushButton("Очистить")
        self.open_btn = QPushButton("Открыть")
        self.save_btn = QPushButton("Сохранить")
        self.size_label = QLabel("Размер: 6")
        self.size_slider = QSlider(Qt.Orientation.Horizontal)
        self.size_slider.setRange(1, 64)
        self.size_slider.setValue(6)
        self.size_slider.setFixedWidth(160)

        self.color_btn.clicked.connect(self.pick_color)
        self.eraser_btn.clicked.connect(self.toggle_eraser)
        self.clear_btn.clicked.connect(self.clear_canvas)
        self.open_btn.clicked.connect(self.open_image)
        self.save_btn.clicked.connect(self.save_image)
        self.size_slider.valueChanged.connect(self.change_size)

        toolbar = QHBoxLayout()
        toolbar.addWidget(title)
        toolbar.addWidget(self.color_btn)
        toolbar.addWidget(self.eraser_btn)
        toolbar.addWidget(self.size_label)
        toolbar.addWidget(self.size_slider)
        toolbar.addStretch(1)
        toolbar.addWidget(self.open_btn)
        toolbar.addWidget(self.save_btn)
        toolbar.addWidget(self.clear_btn)

        layout = QVBoxLayout(self)
        layout.addLayout(toolbar)
        layout.addWidget(self.canvas, 1)

    def pick_color(self) -> None:
        color = QColorDialog.getColor(self.canvas.color, self, "Цвет кисти")
        if color.isValid():
            self.canvas.set_color(color)
            self.eraser_btn.setText("Ластик")

    def toggle_eraser(self) -> None:
        self.canvas.set_eraser(not self.canvas.is_eraser)
        self.eraser_btn.setText("Кисть" if self.canvas.is_eraser else "Ластик")

    def change_size(self, value: int) -> None:
        self.canvas.set_size(value)
        self.size_label.setText(f"Размер: {value}")

    def clear_canvas(self) -> None:
        answer = QMessageBox.question(self, "BlueCord Lite", "Очистить холст?")
        if answer == QMessageBox.StandardButton.Yes:
            self.canvas.clear()

    def open_image(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Открыть изображение",
            str(Path.home()),
            "Images (*.png *.jpg *.jpeg *.bmp)",
        )
        if path and not self.canvas.open_image(path):
            QMessageBox.warning(self, "BlueCord Lite", "Не удалось открыть изображение.")

    def save_image(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Сохранить рисунок",
            str(Path.home() / "bluecord_lite_art.png"),
            "PNG (*.png);;JPEG (*.jpg);;BMP (*.bmp)",
        )
        if not path:
            return
        if Path(path).suffix.lower() not in {".png", ".jpg", ".jpeg", ".bmp"}:
            path += ".png"
        if not self.canvas.save_image(path):
            QMessageBox.warning(self, "BlueCord Lite", "Не удалось сохранить изображение.")
