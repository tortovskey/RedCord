from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class AIEditResult:
    action: str
    title: str
    text: str


class AIEditorService:
    """Offline AI-like editor.

    This is a local mock/editorial assistant. It does not require API keys and does not send text anywhere.
    Later it can be replaced by OpenAI/local model provider.
    """

    def improve_text(self, text: str) -> AIEditResult:
        cleaned = self._normalize(text)
        cleaned = re.sub(r"\bочень\s+", "", cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r"\bпросто\s+", "", cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r"\bкак бы\s+", "", cleaned, flags=re.IGNORECASE)
        return AIEditResult(
            "improve_text",
            "Улучшенный текст",
            cleaned + "\n\n[Редакторская заметка] Проверь ритм фраз, повторы имён и силу глаголов.",
        )

    def summarize(self, text: str) -> AIEditResult:
        sentences = self._sentences(text)
        if not sentences:
            summary = "Текст пустой."
        else:
            summary = " ".join(sentences[:3])
            if len(sentences) > 3:
                summary += " ..."
        return AIEditResult("summarize", "Краткое содержание", summary)

    def expand_scene(self, text: str) -> AIEditResult:
        base = text.strip() or "Сцена пока пустая."
        addition = (
            "\n\n## Что можно усилить\n"
            "- Цель персонажа в сцене.\n"
            "- Препятствие, которое мешает цели.\n"
            "- Деталь окружения, работающая на атмосферу.\n"
            "- Маленький выбор с последствиями.\n"
            "- Финальный крючок для следующей сцены.\n"
        )
        return AIEditResult("expand_scene", "Развитие сцены", base + addition)

    def find_contradictions(self, text: str) -> AIEditResult:
        lower = text.lower()
        checks = []
        markers = {
            "время": ["вчера", "сегодня", "завтра", "утром", "ночью", "вечером"],
            "мотивация": ["хочет", "боится", "цель", "ненавидит", "любит"],
            "локация": ["комната", "город", "лес", "дом", "база", "улица"],
            "сила/правила": ["может", "нельзя", "правило", "способность", "магия", "сила"],
        }
        for title, words in markers.items():
            found = [word for word in words if word in lower]
            checks.append(f"- {title}: найдено {len(found)} маркеров ({', '.join(found) if found else 'нет'}).")

        result = (
            "## Проверка противоречий\n"
            + "\n".join(checks)
            + "\n\n## Вопросы для ручной проверки\n"
            "- Не меняется ли цель персонажа без причины?\n"
            "- Не нарушены ли правила мира?\n"
            "- Совпадают ли время, место и состояние персонажей?\n"
            "- Есть ли последствия у важных решений?\n"
        )
        return AIEditResult("find_contradictions", "Логические противоречия", result)

    def character_questions(self, text: str) -> AIEditResult:
        return AIEditResult(
            "character_questions",
            "Вопросы для персонажа",
            "## Вопросы для проработки персонажа\n"
            "- Чего персонаж хочет прямо сейчас?\n"
            "- Чего он боится признать?\n"
            "- Какая привычка выдаёт его прошлое?\n"
            "- Что он никогда не простит?\n"
            "- Кого он защищает, даже если делает вид, что ему всё равно?\n"
            "- Какой выбор сломает его старую версию?\n\n"
            "## Контекст из текста\n"
            f"{self._normalize(text)[:1200]}",
        )

    def title_ideas(self, text: str) -> AIEditResult:
        words = [w.strip(".,!?;:()[]«»\"'").capitalize() for w in text.split() if len(w) > 4]
        base = []
        for word in words:
            if word and word not in base:
                base.append(word)
            if len(base) >= 4:
                break
        if not base:
            base = ["Тихий", "След", "Граница", "Выбор"]
        ideas = [
            f"{base[0]} и {base[1] if len(base) > 1 else 'тень'}",
            f"После {base[0].lower()}",
            f"Глава: {base[-1]}",
            "Точка невозврата",
            "Цена выбора",
        ]
        return AIEditResult("title_ideas", "Варианты названия", "\n".join(f"- {idea}" for idea in ideas))

    def fix_dialogue(self, text: str) -> AIEditResult:
        lines = []
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped:
                lines.append("")
            elif stripped.startswith("-") or stripped.startswith("—"):
                lines.append("— " + stripped.lstrip("-— ").strip())
            else:
                lines.append(stripped)
        return AIEditResult("fix_dialogue", "Диалоги приведены к единому виду", "\n".join(lines))

    def _normalize(self, text: str) -> str:
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    def _sentences(self, text: str) -> list[str]:
        cleaned = self._normalize(text)
        return [s.strip() for s in re.split(r"(?<=[.!?…])\s+", cleaned) if s.strip()]
