from __future__ import annotations

import sys

from PyQt6.QtWidgets import QApplication, QMainWindow

from redcord import __version__
from redcord.app.theme import build_qss
from redcord.services.settings_service import SettingsService
from redcord.ui.widgets.bluecord_canvas import BlueCordWidget


def main() -> int:
    app = QApplication(sys.argv)
    settings = SettingsService().load()
    app.setApplicationName("BlueCord")
    app.setStyleSheet(build_qss(settings.theme))
    window = QMainWindow()
    window.setWindowTitle(f"BlueCord Lite — RedCord {__version__}")
    window.setCentralWidget(BlueCordWidget())
    window.resize(1100, 740)
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
