from __future__ import annotations

from pathlib import Path

from PyQt6.QtWidgets import (
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
)

from redcord.services.update_service import UpdateErrorForUser, UpdateService


class UpdateDialog(QDialog):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Обновление RedCord")
        self.resize(720, 420)
        self.service = UpdateService()
        self.archive_path: Path | None = None

        self.info = QTextEdit()
        self.info.setReadOnly(True)
        self.info.setPlainText(
            "Выберите ZIP-архив новой версии RedCord.\n\n"
            "Обновлятор распакует код приложения, но сохранит data/, commits/, .env, "
            "локальную базу, настройки, аккаунты и ветки.\n\n"
            "Перед обновлением создаётся резервная копия в data/update_backups/."
        )
        self.path_label = QLabel("Архив не выбран")

        self.choose_btn = QPushButton("Выбрать архив")
        self.update_btn = QPushButton("Установить обновление")
        self.close_btn = QPushButton("Закрыть")

        self.choose_btn.clicked.connect(self.choose_archive)
        self.update_btn.clicked.connect(self.apply_update)
        self.close_btn.clicked.connect(self.close)

        buttons = QHBoxLayout()
        buttons.addWidget(self.choose_btn)
        buttons.addWidget(self.update_btn)
        buttons.addStretch(1)
        buttons.addWidget(self.close_btn)

        layout = QVBoxLayout(self)
        layout.addWidget(self.info)
        layout.addWidget(self.path_label)
        layout.addLayout(buttons)

    def choose_archive(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Архив обновления", str(Path.home()), "ZIP archives (*.zip)")
        if path:
            self.archive_path = Path(path)
            self.path_label.setText(str(self.archive_path))

    def apply_update(self) -> None:
        if self.archive_path is None:
            QMessageBox.information(self, "Обновление", "Сначала выберите ZIP-архив.")
            return
        answer = QMessageBox.question(
            self,
            "Установить обновление",
            "Установить обновление из выбранного архива? После этого перезапустите RedCord.",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            result = self.service.apply_update_from_archive(self.archive_path)
            QMessageBox.information(
                self,
                "Обновление готово",
                result.message + f"\n\nБэкап: {result.backup_dir}",
            )
            self.accept()
        except UpdateErrorForUser as exc:
            QMessageBox.warning(self, "Обновление невозможно", str(exc))
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Ошибка обновления", str(exc))
