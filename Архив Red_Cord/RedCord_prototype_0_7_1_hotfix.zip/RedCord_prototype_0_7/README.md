# RedCord 0.7.1 Hotfix

RedCord 0.7.1 исправляет проблему, когда **BlueCord вылетал после установки**.

## Что изменено

### Разделение BlueCord

Теперь роли разделены:

```text
RedCord / ReC
  Встроенная вкладка BlueCord Lite
  Максимально стабильный простой холст:
  - кисть;
  - ластик;
  - размер кисти;
  - цвет;
  - открыть изображение;
  - сохранить изображение;
  - очистить холст.

BlueCord / BoC
  Полноценная отдельная программа:
  - кисть;
  - карандаш;
  - ластик;
  - линия;
  - прямоугольник;
  - эллипс;
  - заливка;
  - пипетка;
  - текст;
  - undo / redo;
  - opacity;
  - zoom;
  - новый холст;
  - открыть PNG/JPG/BMP;
  - сохранить PNG/JPG/BMP.
```

### Почему BlueCord вылетал

В 0.7 BlueCord standalone запускался через модуль `redcord.app.bluecord` и зависел от части RedCord-настроек. После установки через Inno Setup это могло ломаться из-за путей, ресурсов или окружения.

В 0.7.1 BlueCord вынесен в отдельный пакет:

```text
bluecord/
  app/main.py
  widgets/canvas.py
  assets/bluecord_icon.ico
```

Standalone BlueCord теперь не зависит от RedCord database/config/settings.

## Запуск из исходников

RedCord:

```powershell
python -m redcord.app.main
```

BlueCord standalone:

```powershell
python -m bluecord.app.main
```

Или:

```powershell
scripts\run_bluecord.bat
```

## Сборка

RedCord:

```powershell
scripts\build_exe.bat
```

BlueCord:

```powershell
scripts\build_bluecord.bat
```

Установщик:

```powershell
scripts\build_installer.bat
```

Теперь `build_installer.bat` сам сначала собирает RedCord и BlueCord, проверяет наличие exe-файлов, и только потом запускает Inno Setup.

## Где искать результаты

```text
redcord_build/
  redcord/
    RedCord.exe

bluecord_build/
  BlueCord/
    BlueCord.exe

installer_output/
  RedCord_Setup_0_7_1.exe
```

## Проверка после установки

1. Установи RedCord через `RedCord_Setup_0_7_1.exe`.
2. Запусти RedCord.
3. Проверь вкладку **BlueCord Lite**.
4. Запусти BlueCord отдельно из меню Пуск.
5. Проверь, что BlueCord открывается без вылета.
6. Проверь сохранение PNG/JPG/BMP.
