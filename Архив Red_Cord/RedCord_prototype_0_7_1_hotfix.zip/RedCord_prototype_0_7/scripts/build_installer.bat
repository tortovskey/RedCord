@echo off
setlocal
cd /d "%~dp0.."

echo [RedCord 0.7.1] building installer...

if not exist ".venv\Scripts\activate.bat" (
    echo [Installer] .venv not found.
    pause
    exit /b 1
)

call ".venv\Scripts\activate.bat"

echo.
echo [Installer] Building RedCord first...
call scripts\build_exe.bat
if errorlevel 1 exit /b 1

echo.
echo [Installer] Building BlueCord standalone...
call scripts\build_bluecord.bat
if errorlevel 1 exit /b 1

echo.
echo [Installer] Checking build outputs...
if not exist "redcord_build\redcord\RedCord.exe" (
    echo [Installer] Missing redcord_build\redcord\RedCord.exe
    pause
    exit /b 1
)
if not exist "bluecord_build\BlueCord\BlueCord.exe" (
    echo [Installer] Missing bluecord_build\BlueCord\BlueCord.exe
    pause
    exit /b 1
)

where ISCC.exe >nul 2>nul
if errorlevel 1 (
    if exist "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" (
        set "ISCC=C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
    ) else if exist "C:\Program Files\Inno Setup 6\ISCC.exe" (
        set "ISCC=C:\Program Files\Inno Setup 6\ISCC.exe"
    ) else (
        echo [Installer] Inno Setup 6 not found.
        echo Install Inno Setup 6 or add ISCC.exe to PATH.
        pause
        exit /b 1
    )
) else (
    set "ISCC=ISCC.exe"
)

if exist "installer_output" rmdir /s /q "installer_output"
"%ISCC%" installer\RedCord_Installer.iss

if errorlevel 1 (
    echo [Installer] Build failed.
    pause
    exit /b 1
)

echo.
echo [Installer] Done:
echo   installer_output\RedCord_Setup_0_7_1.exe
pause
endlocal
