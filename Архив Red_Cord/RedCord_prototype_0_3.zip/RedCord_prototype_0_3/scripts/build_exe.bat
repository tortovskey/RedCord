@echo off
setlocal
cd /d "%~dp0.."

echo [RedCord 0.3] building Windows EXE...

if not exist ".venv\Scripts\activate.bat" (
    echo [RedCord] .venv not found.
    pause
    exit /b 1
)

call ".venv\Scripts\activate.bat"
python -m pip install -r requirements.txt
pyinstaller --noconfirm --clean redcord.spec

if errorlevel 1 (
    echo.
    echo [RedCord] Build failed.
    pause
    exit /b 1
)

echo.
echo [RedCord] Build complete. Output: dist\RedCord\
pause
endlocal
