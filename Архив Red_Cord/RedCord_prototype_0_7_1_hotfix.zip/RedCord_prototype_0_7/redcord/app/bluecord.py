from __future__ import annotations

from bluecord.app.main import main


if __name__ == "__main__":
    raise SystemExit(main())
