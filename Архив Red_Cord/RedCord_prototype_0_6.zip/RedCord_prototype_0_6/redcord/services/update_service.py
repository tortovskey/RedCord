from __future__ import annotations

import shutil
import tempfile
import zipfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from redcord.app.config import get_settings


@dataclass
class UpdateResult:
    copied_files: int
    skipped_files: int
    backup_dir: Path
    message: str


class UpdateErrorForUser(RuntimeError):
    """Safe update error to show in UI."""


class UpdateService:
    """Safe archive updater that preserves user data.

    It is designed for source-folder updates and most one-folder PyInstaller builds.
    Data folders are never overwritten.
    """

    SKIP_DIR_NAMES = {
        ".venv",
        "venv",
        "__pycache__",
        ".git",
        "data",
        "commits",
        "redcord_build",
        "build",
        "dist",
    }
    SKIP_FILE_NAMES = {
        ".env",
        "redcord.db",
        "settings.json",
        "accounts.json",
        "branches.json",
        "redcord.log",
    }

    def __init__(self) -> None:
        self.settings = get_settings()

    def apply_update_from_archive(self, archive_path: str | Path) -> UpdateResult:
        archive = Path(archive_path)
        if not archive.exists() or archive.suffix.lower() != ".zip":
            raise UpdateErrorForUser("Выберите ZIP-архив новой версии RedCord.")

        target_dir = self.settings.app_dir
        if not target_dir.exists():
            raise UpdateErrorForUser("Папка приложения не найдена.")

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            try:
                with zipfile.ZipFile(archive, "r") as zip_file:
                    zip_file.extractall(tmp_path)
            except Exception as exc:  # noqa: BLE001
                raise UpdateErrorForUser(f"Не удалось распаковать архив: {exc}") from exc

            source_root = self._find_source_root(tmp_path)
            backup_dir = self._backup_current(target_dir)
            copied, skipped = self._copy_update(source_root, target_dir)

        return UpdateResult(
            copied_files=copied,
            skipped_files=skipped,
            backup_dir=backup_dir,
            message=(
                f"Обновление распаковано. Скопировано файлов: {copied}. "
                f"Пропущено пользовательских файлов: {skipped}. "
                "Перезапустите RedCord."
            ),
        )

    def _find_source_root(self, extracted_root: Path) -> Path:
        candidates = [p for p in extracted_root.rglob("redcord") if p.is_dir()]
        if not candidates:
            raise UpdateErrorForUser("В архиве не найдена папка redcord/. Проверьте архив обновления.")
        return candidates[0].parent

    def _backup_current(self, target_dir: Path) -> Path:
        backup_root = self.settings.data_dir / "update_backups"
        backup_dir = backup_root / datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        backup_dir.mkdir(parents=True, exist_ok=True)

        for name in ["redcord", "scripts", "requirements.txt", "pyproject.toml", "README.md", "redcord.spec"]:
            src = target_dir / name
            if not src.exists():
                continue
            dst = backup_dir / name
            if src.is_dir():
                shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            else:
                shutil.copy2(src, dst)
        return backup_dir

    def _should_skip(self, rel_path: Path) -> bool:
        parts = set(rel_path.parts)
        if parts & self.SKIP_DIR_NAMES:
            return True
        if rel_path.name in self.SKIP_FILE_NAMES:
            return True
        if rel_path.suffix in {".pyc", ".pyo"}:
            return True
        return False

    def _copy_update(self, source_root: Path, target_dir: Path) -> tuple[int, int]:
        copied = 0
        skipped = 0
        for src in source_root.rglob("*"):
            if not src.is_file():
                continue
            rel = src.relative_to(source_root)
            if self._should_skip(rel):
                skipped += 1
                continue
            dst = target_dir / rel
            try:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
                copied += 1
            except PermissionError:
                skipped += 1
            except OSError:
                skipped += 1
        return copied, skipped
