from __future__ import annotations

import logging
import uuid
from pathlib import Path

from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtWidgets import (
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QComboBox,
    QSplitter,
    QStatusBar,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from redcord.app.theme import build_qss, key_by_name, theme_names
from redcord.db.models import Commit, Document, Project
from redcord.services.commit_service import CommitService
from redcord.services.document_service import DocumentService
from redcord.services.import_service import ImportErrorForUser, ImportService
from redcord.services.search_service import SearchService
from redcord.services.template_service import TemplateService
from redcord.ui.dialogs.commit_dialog import CommitDialog
from redcord.ui.dialogs.commit_history_dialog import CommitHistoryDialog
from redcord.ui.dialogs.concept_dialog import ConceptDialog
from redcord.ui.dialogs.new_document_dialog import NewDocumentDialog

logger = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("RedCord — Writer Desktop")
        self.document_service = DocumentService()
        self.template_service = TemplateService()
        self.import_service = ImportService()
        self.commit_service = CommitService()
        self.search_service = SearchService()

        self.projects: dict[str, Project] = {}
        self.documents: dict[str, Document] = {}
        self.search_results: dict[str, Document] = {}
        self.commits: dict[str, Commit] = {}
        self.current_project_id: uuid.UUID | None = None
        self.current_document_id: uuid.UUID | None = None
        self.is_dirty = False
        self.autosave_enabled = True

        self.autosave_timer = QTimer(self)
        self.autosave_timer.setInterval(30_000)
        self.autosave_timer.timeout.connect(self.autosave)
        self.autosave_timer.start()

        self._build_ui()
        self.reload_projects()
        self.set_status("Готово")

    def _build_ui(self) -> None:
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(self._build_left_panel())
        splitter.addWidget(self._build_center_panel())
        splitter.addWidget(self._build_right_panel())
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 3)
        splitter.setStretchFactor(2, 1)
        self.setCentralWidget(splitter)
        self.setStatusBar(QStatusBar())

    def _panel(self) -> QFrame:
        frame = QFrame()
        frame.setObjectName("Panel")
        return frame

    def _build_left_panel(self) -> QWidget:
        panel = self._panel()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        title = QLabel("RedCord")
        title.setObjectName("TitleLabel")
        layout.addWidget(title)

        layout.addWidget(QLabel("Проекты"))
        self.project_list = QListWidget()
        self.project_list.currentItemChanged.connect(self.on_project_selected)
        layout.addWidget(self.project_list, 1)

        self.new_project_btn = QPushButton("Новый проект")
        self.new_project_btn.clicked.connect(self.create_project)
        layout.addWidget(self.new_project_btn)

        layout.addWidget(QLabel("Документы"))
        self.document_list = QListWidget()
        self.document_list.currentItemChanged.connect(self.on_document_selected)
        layout.addWidget(self.document_list, 2)

        self.new_document_btn = QPushButton("Новый документ")
        self.import_btn = QPushButton("Импорт docx/doc")
        self.commit_btn_left = QPushButton("Создать коммит")
        self.history_btn = QPushButton("История коммитов")
        self.concepts_btn = QPushButton("Концепты")
        self.theme_btn = QPushButton("Настройки темы")

        self.new_document_btn.clicked.connect(self.create_document)
        self.import_btn.clicked.connect(self.import_document)
        self.commit_btn_left.clicked.connect(self.create_commit)
        self.history_btn.clicked.connect(self.open_commit_history)
        self.concepts_btn.clicked.connect(self.open_concepts)
        self.theme_btn.clicked.connect(self.change_theme)

        for button in [
            self.new_document_btn,
            self.import_btn,
            self.commit_btn_left,
            self.history_btn,
            self.concepts_btn,
            self.theme_btn,
        ]:
            layout.addWidget(button)
        return panel

    def _build_center_panel(self) -> QWidget:
        panel = self._panel()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        header = QLabel("Редактор документа")
        header.setObjectName("TitleLabel")
        layout.addWidget(header)

        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Название документа")
        self.type_combo = QComboBox()
        for template_type, name in self.template_service.list_templates():
            self.type_combo.addItem(name, template_type)
        self.tags_edit = QLineEdit()
        self.tags_edit.setPlaceholderText("Теги через запятую")
        self.category_edit = QLineEdit()
        self.category_edit.setPlaceholderText("Категория")

        for widget in [self.title_edit, self.type_combo, self.tags_edit, self.category_edit]:
            if isinstance(widget, QLineEdit):
                widget.textChanged.connect(self.mark_dirty)
            elif isinstance(widget, QComboBox):
                widget.currentIndexChanged.connect(self.mark_dirty)
            layout.addWidget(widget)

        self.editor = QTextEdit()
        self.editor.setPlaceholderText("Здесь живёт текст. Иногда он кусается, но это нормально.")
        self.editor.textChanged.connect(self.mark_dirty)
        layout.addWidget(self.editor, 1)

        buttons = QHBoxLayout()
        self.save_btn = QPushButton("Сохранить")
        self.save_btn.setObjectName("AccentButton")
        self.autosave_btn = QPushButton("Автосохранение: включено")
        self.commit_btn = QPushButton("Создать коммит")
        self.rollback_btn = QPushButton("Откатить к коммиту")
        self.save_btn.clicked.connect(self.save_current_document)
        self.autosave_btn.clicked.connect(self.toggle_autosave)
        self.commit_btn.clicked.connect(self.create_commit)
        self.rollback_btn.clicked.connect(self.open_commit_history)
        for button in [self.save_btn, self.autosave_btn, self.commit_btn, self.rollback_btn]:
            buttons.addWidget(button)
        layout.addLayout(buttons)
        return panel

    def _build_right_panel(self) -> QWidget:
        panel = self._panel()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        info_title = QLabel("Информация")
        info_title.setObjectName("TitleLabel")
        layout.addWidget(info_title)
        self.info_label = QLabel("Документ не выбран")
        self.info_label.setWordWrap(True)
        self.info_label.setObjectName("MutedLabel")
        layout.addWidget(self.info_label)

        layout.addWidget(QLabel("Последние коммиты"))
        self.commit_list = QListWidget()
        self.commit_list.itemDoubleClicked.connect(lambda _: self.open_commit_history())
        layout.addWidget(self.commit_list, 1)

        layout.addWidget(QLabel("Быстрый поиск"))
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Название, текст, теги, категория")
        self.search_edit.returnPressed.connect(self.search)
        self.search_btn = QPushButton("Искать")
        self.search_btn.clicked.connect(self.search)
        self.search_list = QListWidget()
        self.search_list.itemDoubleClicked.connect(self.open_search_result)
        layout.addWidget(self.search_edit)
        layout.addWidget(self.search_btn)
        layout.addWidget(self.search_list, 1)
        return panel

    def set_status(self, text: str) -> None:
        self.statusBar().showMessage(text)

    def show_error(self, title: str, exc: Exception | str) -> None:
        logger.exception("%s: %s", title, exc)
        QMessageBox.critical(self, title, str(exc))

    def reload_projects(self) -> None:
        self.project_list.blockSignals(True)
        self.project_list.clear()
        self.projects.clear()
        for project in self.document_service.list_projects():
            item = QListWidgetItem(project.title)
            item.setData(256, str(project.id))
            self.project_list.addItem(item)
            self.projects[str(project.id)] = project
        self.project_list.blockSignals(False)
        if self.project_list.count() > 0 and self.project_list.currentRow() == -1:
            self.project_list.setCurrentRow(0)

    def reload_documents(self) -> None:
        self.document_list.blockSignals(True)
        self.document_list.clear()
        self.documents.clear()
        if self.current_project_id is not None:
            for document in self.document_service.list_documents(self.current_project_id):
                item = QListWidgetItem(f"{document.title}  ·  {document.type}")
                item.setData(256, str(document.id))
                self.document_list.addItem(item)
                self.documents[str(document.id)] = document
        self.document_list.blockSignals(False)

    def on_project_selected(self) -> None:
        item = self.project_list.currentItem()
        if item is None:
            self.current_project_id = None
            return
        self.current_project_id = uuid.UUID(item.data(256))
        self.current_document_id = None
        self.reload_documents()
        self.clear_editor()

    def on_document_selected(self) -> None:
        item = self.document_list.currentItem()
        if item is None:
            return
        document_id = uuid.UUID(item.data(256))
        self.load_document(document_id)

    def clear_editor(self) -> None:
        self.current_document_id = None
        self.title_edit.clear()
        self.tags_edit.clear()
        self.category_edit.clear()
        self.editor.clear()
        self.info_label.setText("Документ не выбран")
        self.commit_list.clear()
        self.is_dirty = False

    def load_document(self, document_id: uuid.UUID) -> None:
        try:
            document = self.document_service.get_document(document_id)
            if document is None:
                raise ValueError("Документ не найден")
            self.current_document_id = document.id
            self.title_edit.blockSignals(True)
            self.tags_edit.blockSignals(True)
            self.category_edit.blockSignals(True)
            self.type_combo.blockSignals(True)
            self.editor.blockSignals(True)

            self.title_edit.setText(document.title)
            index = self.type_combo.findData(document.type)
            self.type_combo.setCurrentIndex(index if index >= 0 else 0)
            self.tags_edit.setText(document.tags)
            self.category_edit.setText(document.category)
            self.editor.setPlainText(document.content)

            self.title_edit.blockSignals(False)
            self.tags_edit.blockSignals(False)
            self.category_edit.blockSignals(False)
            self.type_combo.blockSignals(False)
            self.editor.blockSignals(False)
            self.is_dirty = False
            self.update_info(document)
            self.reload_commits()
            self.set_status("Документ открыт")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка открытия документа", exc)

    def update_info(self, document: Document) -> None:
        self.info_label.setText(
            f"Название: {document.title}\n"
            f"Тип: {document.type}\n"
            f"Теги: {document.tags or '—'}\n"
            f"Категория: {document.category or '—'}\n"
            f"Создан: {document.created_at}\n"
            f"Изменён: {document.updated_at}"
        )

    def reload_commits(self) -> None:
        self.commit_list.clear()
        self.commits.clear()
        if self.current_document_id is None:
            return
        for commit in self.commit_service.list_commits(self.current_document_id)[:10]:
            item = QListWidgetItem(f"{commit.created_at:%H:%M:%S} — {commit.message}")
            item.setData(256, str(commit.id))
            self.commit_list.addItem(item)
            self.commits[str(commit.id)] = commit

    def mark_dirty(self) -> None:
        if self.current_document_id is not None:
            self.is_dirty = True
            self.set_status("Есть несохранённые изменения")

    def create_project(self) -> None:
        title, ok = QInputDialog.getText(self, "Новый проект", "Название проекта:")
        if not ok or not title.strip():
            return
        description, _ = QInputDialog.getMultiLineText(self, "Описание", "Описание проекта:")
        try:
            project = self.document_service.create_project(title, description)
            self.reload_projects()
            for row in range(self.project_list.count()):
                if self.project_list.item(row).data(256) == str(project.id):
                    self.project_list.setCurrentRow(row)
                    break
            self.set_status("Проект создан")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка создания проекта", exc)

    def require_project(self) -> bool:
        if self.current_project_id is None:
            QMessageBox.information(self, "Нужен проект", "Сначала создай или выбери проект.")
            return False
        return True

    def create_document(self) -> None:
        if not self.require_project():
            return
        dialog = NewDocumentDialog(self)
        if dialog.exec() != dialog.DialogCode.Accepted:
            return
        title, doc_type = dialog.values()
        try:
            document = self.document_service.create_document(self.current_project_id, title, doc_type)
            self.reload_documents()
            self.select_document(document.id)
            self.set_status("Документ создан")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка создания документа", exc)

    def select_document(self, document_id: uuid.UUID) -> None:
        for row in range(self.document_list.count()):
            if self.document_list.item(row).data(256) == str(document_id):
                self.document_list.setCurrentRow(row)
                return
        self.load_document(document_id)

    def save_current_document(self) -> bool:
        if self.current_document_id is None:
            return False
        try:
            document = self.document_service.save_document(
                self.current_document_id,
                self.title_edit.text(),
                str(self.type_combo.currentData()),
                self.editor.toPlainText(),
                self.tags_edit.text(),
                self.category_edit.text(),
            )
            self.is_dirty = False
            self.update_info(document)
            self.reload_documents()
            self.set_status("Сохранено")
            return True
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка сохранения", exc)
            return False

    def autosave(self) -> None:
        if not self.autosave_enabled or not self.is_dirty or self.current_document_id is None:
            return
        try:
            if self.save_current_document():
                from datetime import datetime

                self.set_status(f"Автосохранено в {datetime.now():%H:%M:%S}")
        except Exception as exc:  # noqa: BLE001
            logger.exception("Autosave failed")
            QMessageBox.warning(self, "Автосохранение", f"Автосохранение не удалось: {exc}")

    def toggle_autosave(self) -> None:
        self.autosave_enabled = not self.autosave_enabled
        self.autosave_btn.setText(
            "Автосохранение: включено" if self.autosave_enabled else "Автосохранение: выключено"
        )
        self.set_status(self.autosave_btn.text())

    def import_document(self) -> None:
        if not self.require_project():
            return
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Импорт документа",
            str(Path.home()),
            "Word documents (*.docx *.doc)",
        )
        if not path:
            return
        try:
            text = self.import_service.read_file_text(path)
            file_path = Path(path)
            document = self.document_service.create_document(
                self.current_project_id,
                file_path.stem,
                "note",
                text,
                tags="import",
                category="Импорт",
            )
            self.reload_documents()
            self.select_document(document.id)
            self.set_status("Документ импортирован")
        except ImportErrorForUser as exc:
            QMessageBox.warning(self, "Импорт невозможен", str(exc))
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка импорта", exc)

    def create_commit(self) -> None:
        if self.current_document_id is None:
            QMessageBox.information(self, "Коммит", "Сначала открой документ.")
            return
        if self.is_dirty:
            self.save_current_document()
        dialog = CommitDialog(self)
        if dialog.exec() != dialog.DialogCode.Accepted:
            return
        try:
            commit = self.commit_service.create_commit(self.current_document_id, dialog.message())
            self.reload_commits()
            self.set_status(f"Коммит создан: {commit.message}")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка коммита", exc)

    def open_commit_history(self) -> None:
        if self.current_document_id is None:
            QMessageBox.information(self, "История", "Сначала открой документ.")
            return
        dialog = CommitHistoryDialog(self.current_document_id, self)
        if dialog.exec() == dialog.DialogCode.Accepted:
            self.load_document(self.current_document_id)

    def open_concepts(self) -> None:
        if not self.require_project():
            return
        dialog = ConceptDialog(self.current_project_id, self)
        dialog.exec()
        self.reload_documents()

    def change_theme(self) -> None:
        name, ok = QInputDialog.getItem(self, "Тема", "Выбери тему:", theme_names(), 0, False)
        if not ok:
            return
        key = key_by_name(name)
        app = self.window().windowHandle().screen().virtualSiblingAt(self.pos()).parent() if False else None
        del app
        from PyQt6.QtWidgets import QApplication

        QApplication.instance().setStyleSheet(build_qss(key))
        self.set_status(f"Тема применена: {name}")

    def search(self) -> None:
        query = self.search_edit.text().strip()
        self.search_list.clear()
        self.search_results.clear()
        if not query:
            return
        try:
            for document in self.search_service.search_documents(query, self.current_project_id):
                item = QListWidgetItem(f"{document.title} · {document.type} · {document.tags}")
                item.setData(256, str(document.id))
                self.search_list.addItem(item)
                self.search_results[str(document.id)] = document
            self.set_status(f"Найдено: {self.search_list.count()}")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка поиска", exc)

    def open_search_result(self) -> None:
        item = self.search_list.currentItem()
        if item is None:
            return
        document_id = uuid.UUID(item.data(256))
        document = self.search_results.get(str(document_id))
        if document is not None:
            self.current_project_id = document.project_id
            self.reload_documents()
            self.select_document(document_id)
