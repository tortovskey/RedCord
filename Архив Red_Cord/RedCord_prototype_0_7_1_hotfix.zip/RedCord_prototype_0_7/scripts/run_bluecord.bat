@echo off
setlocal
cd /d "%~dp0.."

echo [BlueCord v1.0.1 / BoC] starting...

if not exist ".venv\Scripts\activate.bat" (
    echo [BlueCord] .venv not found.
    pause
    exit /b 1
)

call ".venv\Scripts\activate.bat"
python -m bluecord.app.main

if errorlevel 1 pause
endlocal
