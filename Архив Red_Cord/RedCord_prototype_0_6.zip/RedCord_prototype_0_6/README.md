# RedCord 0.6

RedCord — desktop-редактор для писателей на Python + PyQt6. Версия **0.6** крупно перестраивает интерфейс, добавляет вкладки, встроенный модуль рисования **BlueCord Lite** и безопасный обновлятор из ZIP-архива.

## Главное в 0.6

### Новый интерфейс со вкладками

Теперь приложение разделено на вкладки:

```text
Документы
Концепты
Git / версии
BlueCord
Настройки
```

Левая панель стала проще: проекты, документы, импорт, типы документов. Git-инструменты вынесены в отдельную вкладку.

### Обновлятор RedCord

Во вкладке **Настройки** появилась кнопка **Обновить из ZIP-архива**.

Обновлятор умеет:

- выбрать ZIP-архив новой версии;
- распаковать новую версию;
- скопировать код приложения;
- не трогать пользовательские данные;
- создать резервную копию текущих файлов.

Сохраняются:

```text
data/
commits/
.env
redcord.db
settings.json
accounts.json
branches.json
redcord.log
```

Бэкапы создаются тут:

```text
data/update_backups/
```

> На Windows запущенный `.exe` может быть заблокирован системой. Если обновление не заменяет сам `.exe`, закрой RedCord и повтори обновление из исходников или распакуй архив вручную поверх папки приложения. Пользовательские данные всё равно не должны сбрасываться.

### BlueCord Lite

Добавлен встроенный аналог Krita-lite: **BlueCord**.

Функции первой версии:

- холст для рисования;
- кисть;
- выбор цвета;
- размер кисти;
- ластик;
- очистка холста;
- открыть PNG/JPG;
- сохранить PNG.

BlueCord доступен:

1. как вкладка внутри RedCord;
2. как отдельный запуск:

```powershell
scripts\run_bluecord.bat
```

3. как отдельная сборка EXE:

```powershell
scripts\build_bluecord.bat
```

Результат:

```text
bluecord_build/
  bluecord/
    BlueCord.exe
```

Это сделано как модульный компонент, примерно в духе OBS-плагинов: встроен внутрь RedCord, но может жить отдельно.

## Возможности RedCord

- Проекты.
- Документы.
- Концепты.
- Пользовательские типы документов.
- Импорт `.docx`, `.doc`, `.txt`, `.md`, `.markdown`.
- Импорт папки.
- Экспорт через **Сохранить как...**:
  - `.md`;
  - `.txt`;
  - `.docx`;
  - `.doc`, если установлен LibreOffice;
  - `.pdf`.
- Git-like система:
  - коммиты;
  - история;
  - откат;
  - переименование сообщений;
  - удаление коммитов;
  - ветки-снимки;
  - переключение веток;
  - удаление веток.
- Локальные аккаунты.
- Сохранение настроек.
- Темы:
  - Dark Red;
  - Dark Green;
  - Dark Blue;
  - Dark;
  - White;
  - Dark Purple;
  - Dark Rose.
- BlueCord Lite.

## Установка

```powershell
cd C:\Users\user\Desktop\Codes\RedCord
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -U pip setuptools wheel
pip install -r requirements.txt
```

## Запуск RedCord

```powershell
python -m redcord.app.main
```

Или:

```powershell
scripts\run_redcord.bat
```

## Запуск BlueCord отдельно

```powershell
scripts\run_bluecord.bat
```

## Сборка RedCord EXE

```powershell
scripts\build_exe.bat
```

Результат:

```text
redcord_build/
  redcord/
    RedCord.exe
```

## Сборка BlueCord EXE

```powershell
scripts\build_bluecord.bat
```

Результат:

```text
bluecord_build/
  bluecord/
    BlueCord.exe
```

## Режимы базы данных

### Локальный EXE-режим

Если `.env` нет, RedCord создаёт локальную SQLite-базу:

```text
data/redcord.db
```

### PostgreSQL-режим

Создай `.env`:

```env
DATABASE_URL=postgresql+psycopg://postgres:1986@localhost:5432/record_db
APP_ENV=development
LOG_LEVEL=INFO
REDCORD_THEME=dark_red
COMMIT_DIR=./commits
DATA_DIR=./data
ASSETS_DIR=./redcord/assets
```

Миграции:

```powershell
.\.venv\Scripts\alembic.exe upgrade head
```

## Как проверить 0.6

1. Запусти RedCord.
2. Проверь вкладки: **Документы**, **Концепты**, **Git / версии**, **BlueCord**, **Настройки**.
3. Создай проект.
4. Создай документ.
5. Создай коммит.
6. Перейди во вкладку **Git / версии**.
7. Проверь просмотр, удаление, переименование и откат коммитов.
8. Создай ветку, сохрани снимок, переключись на ветку.
9. Перейди во вкладку **Концепты**, создай концепт и преобразуй его в документ.
10. Перейди во вкладку **BlueCord**, нарисуй что-нибудь и сохрани PNG.
11. Перейди во вкладку **Настройки**, проверь смену темы и обновлятор.
12. Проверь отдельный запуск BlueCord через `scripts\run_bluecord.bat`.

## Ограничения 0.6

- BlueCord Lite пока без слоёв, выделения, истории undo/redo и кистей Krita-уровня.
- Обновлятор не может гарантированно заменить запущенный Windows `.exe`, если файл заблокирован системой.
- Ветки RedCord пока являются snapshot-ветками, не полноценным Git DAG с merge/conflict-resolution.
- `.doc` импорт/экспорт зависит от LibreOffice/antiword/pypandoc.
