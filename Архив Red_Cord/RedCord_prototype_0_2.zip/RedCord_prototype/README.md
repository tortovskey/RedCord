# RedCord

RedCord — настольный редактор для писателей на Python + PyQt6 + PostgreSQL. Первый рабочий прототип умеет создавать проекты, документы по шаблонам, импортировать `.docx`, безопасно обрабатывать `.doc`, сохранять документы, делать Git-like коммиты, откатываться к коммитам, искать материалы, работать с концептами и переключать темы без перезапуска.

## Возможности прототипа

- Проекты и документы.
- Типы документов: персонаж, лор, организация, арка, глава, сцена, таймлайн, предмет, способность, мир, фракция, заметка, концепт.
- Тёмные темы: Dark Red, Dark Green, Dark Blue.
- Импорт `.docx` через `python-docx`.
- Импорт `.doc` через LibreOffice headless, `antiword` или `pypandoc`, если они установлены.
- Простая система коммитов:
  - snapshot в PostgreSQL;
  - markdown-файл в `commits/document_<document_id>/`;
  - просмотр и откат.
- Автосохранение каждые 30 секунд.
- Поиск по названию, содержимому, тегам и категории.
- Раздел концептов.
- Логирование в `redcord.log`.
- Self-healing первого уровня:
  - 3 попытки подключения к БД;
  - автоматическое создание папок `commits/`, `redcord/data/`, `redcord/assets/`;
  - автоматическая загрузка базовых шаблонов;
  - безопасная обработка ошибок импорта, коммитов и автосохранения.

## Установка

```powershell
cd C:\Users\user\Desktop\Codes\RedCord
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -U pip setuptools wheel
pip install -r requirements.txt
```

Если Python 3.12 нет, можно использовать 3.13. Python 3.14 может работать, но для учебного проекта лучше 3.12/3.13.

## Настройка PostgreSQL

Создай базу:

```powershell
& "C:\Program Files\PostgreSQL\18\bin\psql.exe" -U postgres -h localhost -p 5432 -c "CREATE DATABASE record_db;"
```

Скопируй `.env.example` в `.env`:

```powershell
copy .env.example .env
notepad .env
```

Пример для локального PostgreSQL пользователя `postgres`:

```env
DATABASE_URL=postgresql+psycopg://postgres:1986@localhost:5432/record_db
APP_ENV=development
LOG_LEVEL=INFO
REDCORD_THEME=dark_red
COMMIT_DIR=./commits
DATA_DIR=./redcord/data
ASSETS_DIR=./redcord/assets
```

Пароль хранится только в `.env`, не в коде.

## Миграции

```powershell
.\.venv\Scripts\alembic.exe upgrade head
```

Если `alembic` не найден:

```powershell
python -m pip install -r requirements.txt
.\.venv\Scripts\alembic.exe upgrade head
```

## Запуск

```powershell
python -m redcord.app.main
```

Или через Windows-скрипт:

```powershell
scripts\run_redcord.bat
```

## Как проверить

### 1. Создание проекта

Нажми **Новый проект**, введи название. Проект появится в левой панели.

### 2. Создание документа

Выбери проект, нажми **Новый документ**, выбери тип, например **Персонаж**. В редактор вставится шаблон.

### 3. Импорт `.docx`

Нажми **Импорт docx/doc**, выбери `.docx`. Документ создастся в текущем проекте, текст откроется в редакторе.

### 4. Импорт `.doc`

Если установлен LibreOffice, `antiword` или `pypandoc`, RedCord попробует извлечь текст. Если конвертеров нет, появится понятная ошибка, приложение не упадёт.

### 5. Создание коммита

Открой документ, измени текст, нажми **Создать коммит**, введи сообщение. Коммит появится справа и в истории, а snapshot-файл будет создан в `commits/document_<id>/`.

### 6. Откат к коммиту

Нажми **История коммитов**, выбери коммит, нажми **Откатить**. Содержимое документа заменится snapshot-версией, после чего создастся новый rollback-коммит.

### 7. Смена темы

Нажми **Настройки темы**, выбери Dark Red, Dark Green или Dark Blue. Тема применяется сразу.

### 8. Поиск

В правой панели введи слово в поле **Быстрый поиск**. Результаты появятся ниже. Двойной клик открывает документ.

## Известные ограничения первого прототипа

- Markdown пока редактируется как обычный текст, без HTML-preview.
- `.doc` импорт зависит от внешнего конвертера.
- Нет полноценного branch/version graph, только линейные коммиты документа.
- Нет многопользовательского режима.
- Нет AI-ассистента в этой итерации, акцент сделан на рабочем desktop-прототипе.
