# RedCord 0.3

RedCord — настольный редактор для писателей на Python + PyQt6 + PostgreSQL. Версия **0.3** улучшает сохранение, добавляет визуальный индикатор успешного сохранения, кнопку **«Сохранить как...»**, фирменную иконку **ReC** и готовую конфигурацию для сборки **Windows EXE** через PyInstaller.

## Что нового в 0.3

- Кнопка **Сохранить** теперь показывает визуальную галочку `✔` после успешного сохранения.
- Добавлена кнопка **Сохранить как...** для экспорта текущего документа в `.md` или `.txt`.
- Улучшено сохранение текущего документа: список документов теперь обновляется аккуратнее и не теряет активный документ.
- Добавлена фирменная иконка **ReC**:
  - `redcord/assets/redcord_icon.ico`
  - `redcord/assets/redcord_icon.png`
  - `redcord/assets/redcord_icon.svg`
- Окно приложения теперь использует иконку RedCord.
- Добавлена сборка в `.exe` через:
  - `scripts/build_exe.bat`
  - `redcord.spec`
- В `requirements.txt` и `pyproject.toml` добавлен `pyinstaller`.

## Возможности прототипа

- Проекты и документы.
- Типы документов: персонаж, лор, организация, арка, глава, сцена, таймлайн, предмет, способность, мир, фракция, заметка, концепт.
- Тёмные темы: Dark Red, Dark Green, Dark Blue.
- Импорт `.docx` через `python-docx`.
- Импорт `.doc` через LibreOffice headless, `antiword` или `pypandoc`, если они установлены.
- Простая система коммитов:
  - snapshot в PostgreSQL;
  - markdown-файл в `commits/document_<document_id>/`;
  - просмотр и откат.
- Автосохранение каждые 30 секунд.
- Поиск по названию, содержимому, тегам и категории.
- Раздел концептов.
- Логирование в `redcord.log`.
- Self-healing первого уровня:
  - 3 попытки подключения к БД;
  - автоматическое создание папок `commits/`, `redcord/data/`, `redcord/assets/`;
  - автоматическая загрузка базовых шаблонов;
  - безопасная обработка ошибок импорта, коммитов и автосохранения.

## Установка

```powershell
cd C:\Users\user\Desktop\Codes\RedCord
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -U pip setuptools wheel
pip install -r requirements.txt
```

Если Python 3.12 нет, можно использовать 3.13. Python 3.14 может работать, но для учебного проекта лучше 3.12/3.13.

## Настройка PostgreSQL

Создай базу:

```powershell
& "C:\Program Files\PostgreSQL\18\bin\psql.exe" -U postgres -h localhost -p 5432 -c "CREATE DATABASE record_db;"
```

Скопируй `.env.example` в `.env`:

```powershell
copy .env.example .env
notepad .env
```

Пример для локального PostgreSQL пользователя `postgres`:

```env
DATABASE_URL=postgresql+psycopg://postgres:1986@localhost:5432/record_db
APP_ENV=development
LOG_LEVEL=INFO
REDCORD_THEME=dark_red
COMMIT_DIR=./commits
DATA_DIR=./redcord/data
ASSETS_DIR=./redcord/assets
```

## Миграции

```powershell
.\.venv\Scripts\alembic.exe upgrade head
```

## Запуск

```powershell
python -m redcord.app.main
```

Или через Windows-скрипт:

```powershell
scripts\run_redcord.bat
```

## Сборка EXE

```powershell
scripts\build_exe.bat
```

После успешной сборки результат будет в папке:

```text
dist\RedCord\
```

Если хочешь собрать вручную:

```powershell
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
pyinstaller --noconfirm --clean redcord.spec
```

## Как проверить новые функции 0.3

### Галочка после сохранения

1. Открой документ.
2. Измени текст.
3. Нажми **Сохранить**.
4. Кнопка на короткое время изменится на `✔ Сохранено`, а под кнопками появится зелёная подсказка.

### Сохранить как...

1. Открой документ.
2. Нажми **Сохранить как...**.
3. Выбери `.md` или `.txt`.
4. Документ экспортируется в файл на диске.

### Иконка приложения

1. Запусти `python -m redcord.app.main`.
2. У окна должна быть иконка **ReC**.
3. После сборки EXE та же иконка должна использоваться для `.exe`.

## Известные ограничения

- Markdown пока редактируется как обычный текст, без HTML-preview.
- `.doc` импорт зависит от внешнего конвертера.
- Нет полноценного branch/version graph, только линейные коммиты документа.
- Нет многопользовательского режима.
- Нет AI-ассистента в этой итерации.
- EXE-файл в архив не вложен, потому что сборка Windows `.exe` должна выполняться на Windows-машине через PyInstaller.
