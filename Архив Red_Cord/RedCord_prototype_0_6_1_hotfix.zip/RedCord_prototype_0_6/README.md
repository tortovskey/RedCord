# RedCord 0.6.1 Hotfix

Быстрый hotfix для RedCord 0.6.0.

## Исправлено

- Белая верхняя полоса вкладок заменена на тёмную.
- Добавлены QSS-стили для:
  - `QTabWidget`
  - `QTabBar`
  - `QMenuBar`
  - `QMenu`
  - `QToolBar`
  - `QStatusBar`
- Вкладки теперь используют цвета текущей темы, а не системный белый цвет Windows.
- Версия обновлена до `0.6.1`.

## Запуск

```powershell
python -m redcord.app.main
```

## Сборка EXE

```powershell
scripts\build_exe.bat
```

Результат:

```text
redcord_build/
  redcord/
    RedCord.exe
```

## Что проверить

1. Запусти RedCord.
2. Посмотри на верхние вкладки:
   - Документы
   - Концепты
   - Git / версии
   - BlueCord
   - Настройки
3. Белого фона быть не должно.
4. Переключи темы и проверь, что вкладки остаются в цветах темы.
