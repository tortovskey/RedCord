from __future__ import annotations

import importlib.util
import shutil
import subprocess
import tempfile
from pathlib import Path

from docx import Document as DocxDocument


class ImportErrorForUser(RuntimeError):
    """Import error with message safe to show in UI."""


class ImportService:
    def read_file_text(self, path: str | Path) -> str:
        file_path = Path(path)
        suffix = file_path.suffix.lower()
        if suffix == ".docx":
            return self._read_docx(file_path)
        if suffix == ".doc":
            return self._read_doc(file_path)
        raise ImportErrorForUser("Поддерживаются только .docx и .doc файлы.")

    def _read_docx(self, path: Path) -> str:
        try:
            document = DocxDocument(path)
            paragraphs = [paragraph.text for paragraph in document.paragraphs]
            return "\n".join(paragraphs).strip()
        except Exception as exc:  # noqa: BLE001
            raise ImportErrorForUser(f"Не удалось прочитать .docx файл: {exc}") from exc

    def _read_doc(self, path: Path) -> str:
        text = self._try_libreoffice(path)
        if text:
            return text

        text = self._try_antiword(path)
        if text:
            return text

        text = self._try_pypandoc(path)
        if text:
            return text

        raise ImportErrorForUser(
            "Формат .doc требует установленный LibreOffice или конвертер. "
            "Установите LibreOffice или сохраните файл как .docx."
        )

    def _try_libreoffice(self, path: Path) -> str | None:
        executable = shutil.which("soffice") or shutil.which("libreoffice")
        if executable is None:
            return None
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            try:
                subprocess.run(
                    [
                        executable,
                        "--headless",
                        "--convert-to",
                        "docx",
                        "--outdir",
                        str(tmp_path),
                        str(path),
                    ],
                    check=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=45,
                )
                converted = tmp_path / f"{path.stem}.docx"
                if converted.exists():
                    return self._read_docx(converted)
            except Exception:
                return None
        return None

    def _try_antiword(self, path: Path) -> str | None:
        executable = shutil.which("antiword")
        if executable is None:
            return None
        try:
            result = subprocess.run(
                [executable, str(path)],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=30,
            )
            return result.stdout.decode("utf-8", errors="replace").strip()
        except Exception:
            return None

    def _try_pypandoc(self, path: Path) -> str | None:
        if importlib.util.find_spec("pypandoc") is None:
            return None
        try:
            import pypandoc  # type: ignore

            return str(pypandoc.convert_file(str(path), "plain")).strip()
        except Exception:
            return None
