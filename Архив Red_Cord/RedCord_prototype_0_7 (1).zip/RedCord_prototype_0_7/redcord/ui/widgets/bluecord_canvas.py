from __future__ import annotations

from enum import Enum
from pathlib import Path

from PyQt6.QtCore import QPoint, QRect, Qt
from PyQt6.QtGui import QColor, QImage, QMouseEvent, QPainter, QPen, QPixmap
from PyQt6.QtWidgets import (
    QComboBox,
    QColorDialog,
    QFileDialog,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QMessageBox,
    QPushButton,
    QSlider,
    QVBoxLayout,
    QWidget,
)


class Tool(str, Enum):
    BRUSH = "Кисть"
    PENCIL = "Карандаш"
    ERASER = "Ластик"
    LINE = "Линия"
    RECTANGLE = "Прямоугольник"
    ELLIPSE = "Эллипс"
    FILL = "Заливка"
    PICKER = "Пипетка"
    TEXT = "Текст"


class DrawingCanvas(QWidget):
    """BlueCord v1 raster canvas: Paint-like base with Krita-lite comforts."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setMinimumSize(900, 620)
        self.image = QImage(1920, 1080, QImage.Format.Format_ARGB32)
        self.image.fill(QColor("white"))
        self.brush_color = QColor("#0c5cff")
        self.secondary_color = QColor("white")
        self.brush_size = 8
        self.opacity = 255
        self.tool = Tool.BRUSH
        self.zoom = 1.0
        self._drawing = False
        self._start_point = QPoint()
        self._last_point = QPoint()
        self._preview_image: QImage | None = None
        self.undo_stack: list[QImage] = []
        self.redo_stack: list[QImage] = []

    def push_undo(self) -> None:
        self.undo_stack.append(self.image.copy())
        if len(self.undo_stack) > 40:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def undo(self) -> None:
        if not self.undo_stack:
            return
        self.redo_stack.append(self.image.copy())
        self.image = self.undo_stack.pop()
        self.update()

    def redo(self) -> None:
        if not self.redo_stack:
            return
        self.undo_stack.append(self.image.copy())
        self.image = self.redo_stack.pop()
        self.update()

    def set_tool(self, tool: Tool) -> None:
        self.tool = tool

    def set_brush_size(self, value: int) -> None:
        self.brush_size = max(1, value)

    def set_opacity(self, value: int) -> None:
        self.opacity = max(1, min(255, value))

    def set_color(self, color: QColor) -> None:
        self.brush_color = color

    def new_canvas(self, width: int = 1920, height: int = 1080) -> None:
        self.push_undo()
        self.image = QImage(width, height, QImage.Format.Format_ARGB32)
        self.image.fill(QColor("white"))
        self.update()

    def clear(self) -> None:
        self.push_undo()
        self.image.fill(QColor("white"))
        self.update()

    def open_image(self, path: str | Path) -> bool:
        loaded = QImage(str(path))
        if loaded.isNull():
            return False
        self.push_undo()
        self.image = loaded.convertToFormat(QImage.Format.Format_ARGB32)
        self.update()
        return True

    def save_image(self, path: str | Path) -> bool:
        suffix = Path(path).suffix.lower()
        fmt = "PNG"
        if suffix in {".jpg", ".jpeg"}:
            fmt = "JPG"
        elif suffix == ".bmp":
            fmt = "BMP"
        return self.image.save(str(path), fmt)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.fillRect(QRect(0, 0, self.width(), self.height()), QColor("#101720"))
        source = self._preview_image if self._preview_image is not None else self.image
        target_size = self._display_size(source)
        scaled = source.scaled(target_size, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        x = (self.width() - scaled.width()) // 2
        y = (self.height() - scaled.height()) // 2
        painter.fillRect(QRect(x - 8, y - 8, scaled.width() + 16, scaled.height() + 16), QColor("#1c2533"))
        painter.drawImage(x, y, scaled)

    def _display_size(self, image: QImage) -> QPoint:
        max_w = max(1, int(self.width() * self.zoom))
        max_h = max(1, int(self.height() * self.zoom))
        scaled = image.scaled(max_w, max_h, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        return QPoint(scaled.width(), scaled.height())

    def _map_to_image(self, point: QPoint) -> QPoint:
        source = self.image
        target_size = self._display_size(source)
        scaled = source.scaled(target_size.x(), target_size.y(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        x_offset = (self.width() - scaled.width()) // 2
        y_offset = (self.height() - scaled.height()) // 2
        x = int((point.x() - x_offset) * source.width() / max(1, scaled.width()))
        y = int((point.y() - y_offset) * source.height() / max(1, scaled.height()))
        return QPoint(max(0, min(source.width() - 1, x)), max(0, min(source.height() - 1, y)))

    def _active_color(self) -> QColor:
        if self.tool == Tool.ERASER:
            return QColor("white")
        color = QColor(self.brush_color)
        color.setAlpha(self.opacity)
        return color

    def _pen(self) -> QPen:
        size = 1 if self.tool == Tool.PENCIL else self.brush_size
        return QPen(self._active_color(), size, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)

    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() != Qt.MouseButton.LeftButton:
            return
        point = self._map_to_image(event.position().toPoint())

        if self.tool == Tool.PICKER:
            self.brush_color = QColor(self.image.pixelColor(point))
            self.update()
            return
        if self.tool == Tool.FILL:
            self.push_undo()
            self._flood_fill(point, self.image.pixelColor(point), self.brush_color)
            self.update()
            return
        if self.tool == Tool.TEXT:
            text, ok = QInputDialog.getText(self, "BlueCord Text", "Текст:")
            if ok and text:
                self.push_undo()
                painter = QPainter(self.image)
                painter.setPen(self._pen())
                font = painter.font()
                font.setPointSize(max(10, self.brush_size * 3))
                painter.setFont(font)
                painter.drawText(point, text)
                painter.end()
                self.update()
            return

        self.push_undo()
        self._drawing = True
        self._start_point = point
        self._last_point = point

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if not self._drawing:
            return
        current = self._map_to_image(event.position().toPoint())
        if self.tool in {Tool.BRUSH, Tool.PENCIL, Tool.ERASER}:
            painter = QPainter(self.image)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, self.tool != Tool.PENCIL)
            painter.setPen(self._pen())
            painter.drawLine(self._last_point, current)
            painter.end()
            self._last_point = current
            self.update()
        else:
            self._preview_image = self.image.copy()
            self._draw_shape(self._preview_image, self._start_point, current)
            self.update()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() != Qt.MouseButton.LeftButton or not self._drawing:
            return
        current = self._map_to_image(event.position().toPoint())
        if self.tool in {Tool.LINE, Tool.RECTANGLE, Tool.ELLIPSE}:
            self._draw_shape(self.image, self._start_point, current)
        self._preview_image = None
        self._drawing = False
        self.update()

    def _draw_shape(self, target: QImage, start: QPoint, end: QPoint) -> None:
        painter = QPainter(target)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setPen(self._pen())
        rect = QRect(start, end).normalized()
        if self.tool == Tool.LINE:
            painter.drawLine(start, end)
        elif self.tool == Tool.RECTANGLE:
            painter.drawRect(rect)
        elif self.tool == Tool.ELLIPSE:
            painter.drawEllipse(rect)
        painter.end()

    def _flood_fill(self, start: QPoint, target_color: QColor, replacement: QColor) -> None:
        if target_color == replacement:
            return
        width, height = self.image.width(), self.image.height()
        stack = [start]
        seen: set[tuple[int, int]] = set()
        limit = width * height
        while stack and len(seen) < limit:
            point = stack.pop()
            x, y = point.x(), point.y()
            if (x, y) in seen or x < 0 or y < 0 or x >= width or y >= height:
                continue
            seen.add((x, y))
            if self.image.pixelColor(x, y) != target_color:
                continue
            self.image.setPixelColor(x, y, replacement)
            stack.extend([QPoint(x + 1, y), QPoint(x - 1, y), QPoint(x, y + 1), QPoint(x, y - 1)])


class BlueCordWidget(QWidget):
    """BlueCord v1: Paint + Krita-lite drawing tab embedded into RedCord."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.canvas = DrawingCanvas()

        self.tool_combo = QComboBox()
        for tool in Tool:
            self.tool_combo.addItem(tool.value, tool)
        self.tool_combo.currentIndexChanged.connect(self.change_tool)

        self.color_btn = QPushButton("Цвет")
        self.color_btn.clicked.connect(self.pick_color)
        self.undo_btn = QPushButton("Undo")
        self.redo_btn = QPushButton("Redo")
        self.undo_btn.clicked.connect(self.canvas.undo)
        self.redo_btn.clicked.connect(self.canvas.redo)

        self.new_btn = QPushButton("Новый")
        self.clear_btn = QPushButton("Очистить")
        self.open_btn = QPushButton("Открыть")
        self.save_btn = QPushButton("Сохранить")
        self.new_btn.clicked.connect(self.new_canvas)
        self.clear_btn.clicked.connect(self.clear_canvas)
        self.open_btn.clicked.connect(self.open_image)
        self.save_btn.clicked.connect(self.save_image)

        self.size_label = QLabel("Размер: 8")
        self.size_slider = QSlider(Qt.Orientation.Horizontal)
        self.size_slider.setRange(1, 96)
        self.size_slider.setValue(8)
        self.size_slider.setFixedWidth(160)
        self.size_slider.valueChanged.connect(self.change_size)

        self.opacity_label = QLabel("Opacity: 100%")
        self.opacity_slider = QSlider(Qt.Orientation.Horizontal)
        self.opacity_slider.setRange(1, 100)
        self.opacity_slider.setValue(100)
        self.opacity_slider.setFixedWidth(160)
        self.opacity_slider.valueChanged.connect(self.change_opacity)

        self.zoom_label = QLabel("Zoom: 100%")
        self.zoom_slider = QSlider(Qt.Orientation.Horizontal)
        self.zoom_slider.setRange(25, 200)
        self.zoom_slider.setValue(100)
        self.zoom_slider.setFixedWidth(160)
        self.zoom_slider.valueChanged.connect(self.change_zoom)

        toolbar = QHBoxLayout()
        toolbar.addWidget(QLabel("BlueCord v1 · BoC"))
        toolbar.addWidget(self.tool_combo)
        toolbar.addWidget(self.color_btn)
        toolbar.addWidget(self.size_label)
        toolbar.addWidget(self.size_slider)
        toolbar.addWidget(self.opacity_label)
        toolbar.addWidget(self.opacity_slider)
        toolbar.addWidget(self.zoom_label)
        toolbar.addWidget(self.zoom_slider)
        toolbar.addStretch(1)
        for button in [self.undo_btn, self.redo_btn, self.new_btn, self.open_btn, self.save_btn, self.clear_btn]:
            toolbar.addWidget(button)

        layout = QVBoxLayout(self)
        layout.addLayout(toolbar)
        layout.addWidget(self.canvas, 1)

    def change_tool(self) -> None:
        self.canvas.set_tool(self.tool_combo.currentData())

    def pick_color(self) -> None:
        color = QColorDialog.getColor(self.canvas.brush_color, self, "Цвет кисти")
        if color.isValid():
            self.canvas.set_color(color)

    def change_size(self, value: int) -> None:
        self.canvas.set_brush_size(value)
        self.size_label.setText(f"Размер: {value}")

    def change_opacity(self, value: int) -> None:
        self.canvas.set_opacity(int(255 * value / 100))
        self.opacity_label.setText(f"Opacity: {value}%")

    def change_zoom(self, value: int) -> None:
        self.canvas.zoom = value / 100
        self.zoom_label.setText(f"Zoom: {value}%")
        self.canvas.update()

    def new_canvas(self) -> None:
        width, ok = QInputDialog.getInt(self, "Новый холст", "Ширина:", 1920, 64, 8000)
        if not ok:
            return
        height, ok = QInputDialog.getInt(self, "Новый холст", "Высота:", 1080, 64, 8000)
        if ok:
            self.canvas.new_canvas(width, height)

    def clear_canvas(self) -> None:
        answer = QMessageBox.question(self, "BlueCord", "Очистить холст?")
        if answer == QMessageBox.StandardButton.Yes:
            self.canvas.clear()

    def open_image(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Открыть изображение",
            str(Path.home()),
            "Images (*.png *.jpg *.jpeg *.bmp)",
        )
        if path and not self.canvas.open_image(path):
            QMessageBox.warning(self, "BlueCord", "Не удалось открыть изображение.")

    def save_image(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Сохранить рисунок",
            str(Path.home() / "bluecord_art.png"),
            "PNG (*.png);;JPEG (*.jpg);;BMP (*.bmp)",
        )
        if not path:
            return
        if Path(path).suffix.lower() not in {".png", ".jpg", ".jpeg", ".bmp"}:
            path += ".png"
        if not self.canvas.save_image(path):
            QMessageBox.warning(self, "BlueCord", "Не удалось сохранить изображение.")
