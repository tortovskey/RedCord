from __future__ import annotations

import logging
import re
import uuid
from pathlib import Path

from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtGui import QIcon, QTextDocument
from PyQt6.QtPrintSupport import QPrinter
from PyQt6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QComboBox,
    QSplitter,
    QStatusBar,
    QStyle,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from redcord import __version__
from redcord.app.config import get_settings
from redcord.app.theme import build_qss, key_by_name, theme_names
from redcord.db.models import Commit, Document, Project
from redcord.services.branch_service import BranchService
from redcord.services.commit_service import CommitService
from redcord.services.document_service import DocumentService
from redcord.services.export_service import ExportErrorForUser, ExportService
from redcord.services.import_service import ImportErrorForUser, ImportService
from redcord.services.search_service import SearchService
from redcord.services.account_service import AccountService
from redcord.services.settings_service import SettingsService
from redcord.services.template_service import TemplateService
from redcord.ui.dialogs.commit_dialog import CommitDialog
from redcord.ui.dialogs.commit_history_dialog import CommitHistoryDialog
from redcord.ui.dialogs.concept_dialog import ConceptDialog
from redcord.ui.dialogs.new_document_dialog import NewDocumentDialog
from redcord.ui.dialogs.profile_settings_dialog import ProfileSettingsDialog
from redcord.ui.dialogs.template_manager_dialog import TemplateManagerDialog

logger = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"RedCord {__version__} — Writer Desktop")
        self._set_window_icon()
        self.document_service = DocumentService()
        self.template_service = TemplateService()
        self.import_service = ImportService()
        self.export_service = ExportService()
        self.commit_service = CommitService()
        self.branch_service = BranchService()
        self.search_service = SearchService()
        self.settings_service = SettingsService()
        self.account_service = AccountService()
        self.user_settings = self.settings_service.load()
        self.active_account = self.account_service.active_account()

        self.projects: dict[str, Project] = {}
        self.documents: dict[str, Document] = {}
        self.search_results: dict[str, Document] = {}
        self.commits: dict[str, Commit] = {}
        self.current_project_id: uuid.UUID | None = None
        self.current_document_id: uuid.UUID | None = None
        self.is_dirty = False
        self.autosave_enabled = self.user_settings.autosave_enabled

        self.autosave_timer = QTimer(self)
        self.autosave_timer.setInterval(30_000)
        self.autosave_timer.timeout.connect(self.autosave)
        self.autosave_timer.start()

        self.save_feedback_timer = QTimer(self)
        self.save_feedback_timer.setSingleShot(True)
        self.save_feedback_timer.timeout.connect(self._restore_save_button)

        self._build_ui()
        self.reload_projects()
        self.set_status("Готово")

    def _set_window_icon(self) -> None:
        settings = get_settings()
        icon_path = settings.assets_dir / "redcord_icon.ico"
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))
            return
        png_path = settings.assets_dir / "redcord_icon.png"
        if png_path.exists():
            self.setWindowIcon(QIcon(str(png_path)))

    def _build_ui(self) -> None:
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(self._build_left_panel())
        splitter.addWidget(self._build_center_panel())
        splitter.addWidget(self._build_right_panel())
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 3)
        splitter.setStretchFactor(2, 1)
        self.setCentralWidget(splitter)
        self.setStatusBar(QStatusBar())

    def _panel(self) -> QFrame:
        frame = QFrame()
        frame.setObjectName("Panel")
        return frame

    def _standard_icon(self, icon_name: QStyle.StandardPixmap) -> QIcon:
        return self.style().standardIcon(icon_name)

    def _build_left_panel(self) -> QWidget:
        panel = self._panel()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        title = QLabel(f"RedCord {__version__} · {self.active_account.display_name}")
        title.setObjectName("TitleLabel")
        layout.addWidget(title)

        layout.addWidget(QLabel("Проекты"))
        self.project_list = QListWidget()
        self.project_list.currentItemChanged.connect(self.on_project_selected)
        layout.addWidget(self.project_list, 1)

        self.new_project_btn = QPushButton("Новый проект")
        self.new_project_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_FileDialogNewFolder))
        self.new_project_btn.clicked.connect(self.create_project)
        layout.addWidget(self.new_project_btn)

        layout.addWidget(QLabel("Документы"))
        self.document_list = QListWidget()
        self.document_list.currentItemChanged.connect(self.on_document_selected)
        layout.addWidget(self.document_list, 2)

        self.new_document_btn = QPushButton("Новый документ")
        self.new_document_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_FileIcon))
        self.import_btn = QPushButton("Импорт файла")
        self.import_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_DialogOpenButton))
        self.import_folder_btn = QPushButton("Импорт папки")
        self.import_folder_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_DirOpenIcon))
        self.commit_btn_left = QPushButton("Создать коммит")
        self.commit_btn_left.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_CommandLink))
        self.history_btn = QPushButton("История коммитов")
        self.history_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_FileDialogDetailedView))
        self.concepts_btn = QPushButton("Концепты")
        self.concepts_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_FileDialogContentsView))
        self.theme_btn = QPushButton("Настройки темы")
        self.theme_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_DesktopIcon))
        self.types_btn = QPushButton("Типы документов")
        self.types_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_FileDialogInfoView))
        self.profile_btn = QPushButton("Профиль / настройки")
        self.profile_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_DirHomeIcon))

        self.new_document_btn.clicked.connect(self.create_document)
        self.import_btn.clicked.connect(self.import_document)
        self.import_folder_btn.clicked.connect(self.import_folder)
        self.commit_btn_left.clicked.connect(self.create_commit)
        self.history_btn.clicked.connect(self.open_commit_history)
        self.concepts_btn.clicked.connect(self.open_concepts)
        self.theme_btn.clicked.connect(self.change_theme)
        self.types_btn.clicked.connect(self.open_template_manager)
        self.profile_btn.clicked.connect(self.open_profile_settings)

        for button in [
            self.new_document_btn,
            self.import_btn,
            self.import_folder_btn,
            self.concepts_btn,
            self.types_btn,
            self.profile_btn,
        ]:
            layout.addWidget(button)
        return panel

    def _build_center_panel(self) -> QWidget:
        panel = self._panel()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        header = QLabel("Редактор документа")
        header.setObjectName("TitleLabel")
        layout.addWidget(header)

        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Название документа")
        self.type_combo = QComboBox()
        for template_type, name in self.template_service.list_templates():
            self.type_combo.addItem(name, template_type)
        self.tags_edit = QLineEdit()
        self.tags_edit.setPlaceholderText("Теги через запятую")
        self.category_edit = QLineEdit()
        self.category_edit.setPlaceholderText("Категория")

        for widget in [self.title_edit, self.type_combo, self.tags_edit, self.category_edit]:
            if isinstance(widget, QLineEdit):
                widget.textChanged.connect(self.mark_dirty)
            elif isinstance(widget, QComboBox):
                widget.currentIndexChanged.connect(self.mark_dirty)
            layout.addWidget(widget)

        self.editor = QTextEdit()
        self.editor.setPlaceholderText("Здесь живёт текст. Иногда он кусается, но это нормально.")
        self.editor.textChanged.connect(self.mark_dirty)
        layout.addWidget(self.editor, 1)

        buttons = QHBoxLayout()
        self.save_btn = QPushButton("Сохранить")
        self.save_btn.setObjectName("AccentButton")
        self.save_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_DialogSaveButton))
        self.save_as_btn = QPushButton("Сохранить как...")
        self.save_as_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_DriveFDIcon))
        self.autosave_btn = QPushButton("Автосохранение: включено" if self.autosave_enabled else "Автосохранение: выключено")
        self.autosave_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_BrowserReload))
        self.commit_btn = QPushButton("Создать коммит")
        self.commit_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_CommandLink))
        self.rollback_btn = QPushButton("Откатить к коммиту")
        self.rollback_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_ArrowBack))
        self.save_btn.clicked.connect(self.save_current_document)
        self.save_as_btn.clicked.connect(self.save_as_file)
        self.autosave_btn.clicked.connect(self.toggle_autosave)
        self.commit_btn.clicked.connect(self.create_commit)
        self.rollback_btn.clicked.connect(self.open_commit_history)
        for button in [self.save_btn, self.save_as_btn, self.autosave_btn, self.commit_btn, self.rollback_btn]:
            buttons.addWidget(button)
        layout.addLayout(buttons)

        self.save_feedback_label = QLabel("✔ Сохранено")
        self.save_feedback_label.setObjectName("SuccessLabel")
        self.save_feedback_label.hide()
        layout.addWidget(self.save_feedback_label)
        return panel

    def _build_right_panel(self) -> QWidget:
        panel = self._panel()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        info_title = QLabel("Информация")
        info_title.setObjectName("TitleLabel")
        layout.addWidget(info_title)
        self.info_label = QLabel("Документ не выбран")
        self.info_label.setWordWrap(True)
        self.info_label.setObjectName("MutedLabel")
        layout.addWidget(self.info_label)

        layout.addWidget(QLabel("Последние коммиты"))
        self.commit_list = QListWidget()
        self.commit_list.itemDoubleClicked.connect(lambda _: self.open_commit_history())
        layout.addWidget(self.commit_list, 1)

        commit_buttons = QHBoxLayout()
        self.commit_history_small_btn = QPushButton("История")
        self.commit_delete_small_btn = QPushButton("Удалить")
        self.commit_delete_small_btn.setObjectName("DangerButton")
        self.commit_history_small_btn.clicked.connect(self.open_commit_history)
        self.commit_delete_small_btn.clicked.connect(self.delete_selected_commit_from_panel)
        commit_buttons.addWidget(self.commit_history_small_btn)
        commit_buttons.addWidget(self.commit_delete_small_btn)
        layout.addLayout(commit_buttons)

        branch_title = QLabel("Ветки")
        branch_title.setObjectName("SectionLabel")
        layout.addWidget(branch_title)
        self.branch_list = QListWidget()
        layout.addWidget(self.branch_list, 1)

        branch_buttons1 = QHBoxLayout()
        self.branch_new_btn = QPushButton("Новая")
        self.branch_save_btn = QPushButton("Сохранить")
        self.branch_new_btn.clicked.connect(self.create_branch)
        self.branch_save_btn.clicked.connect(self.save_branch_snapshot)
        branch_buttons1.addWidget(self.branch_new_btn)
        branch_buttons1.addWidget(self.branch_save_btn)
        layout.addLayout(branch_buttons1)

        branch_buttons2 = QHBoxLayout()
        self.branch_checkout_btn = QPushButton("Переключить")
        self.branch_delete_btn = QPushButton("Удалить")
        self.branch_delete_btn.setObjectName("DangerButton")
        self.branch_checkout_btn.clicked.connect(self.checkout_branch)
        self.branch_delete_btn.clicked.connect(self.delete_branch)
        branch_buttons2.addWidget(self.branch_checkout_btn)
        branch_buttons2.addWidget(self.branch_delete_btn)
        layout.addLayout(branch_buttons2)

        layout.addWidget(QLabel("Быстрый поиск"))
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Название, текст, теги, категория")
        self.search_edit.returnPressed.connect(self.search)
        self.search_btn = QPushButton("Искать")
        self.search_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_FileDialogContentsView))
        self.search_btn.clicked.connect(self.search)
        self.search_list = QListWidget()
        self.search_list.itemDoubleClicked.connect(self.open_search_result)
        layout.addWidget(self.search_edit)
        layout.addWidget(self.search_btn)
        layout.addWidget(self.search_list, 1)
        return panel

    def set_status(self, text: str) -> None:
        self.statusBar().showMessage(text)

    def show_error(self, title: str, exc: Exception | str) -> None:
        logger.exception("%s: %s", title, exc)
        QMessageBox.critical(self, title, str(exc))

    def reload_projects(self) -> None:
        selected_id = None
        item = self.project_list.currentItem()
        if item is not None:
            selected_id = item.data(256)

        self.project_list.blockSignals(True)
        self.project_list.clear()
        self.projects.clear()
        for project in self.document_service.list_projects():
            row_item = QListWidgetItem(project.title)
            row_item.setData(256, str(project.id))
            self.project_list.addItem(row_item)
            self.projects[str(project.id)] = project
        self.project_list.blockSignals(False)
        if self.project_list.count() > 0:
            target = selected_id or (str(self.current_project_id) if self.current_project_id else None)
            if target:
                for row in range(self.project_list.count()):
                    if self.project_list.item(row).data(256) == target:
                        self.project_list.setCurrentRow(row)
                        return
            if self.project_list.currentRow() == -1:
                self.project_list.setCurrentRow(0)

    def reload_documents(self, select_document_id: uuid.UUID | None = None) -> None:
        self.document_list.blockSignals(True)
        self.document_list.clear()
        self.documents.clear()
        if self.current_project_id is not None:
            for document in self.document_service.list_documents(self.current_project_id):
                item = QListWidgetItem(f"{document.title}  ·  {document.type}")
                item.setData(256, str(document.id))
                self.document_list.addItem(item)
                self.documents[str(document.id)] = document
        self.document_list.blockSignals(False)

        target = str(select_document_id or self.current_document_id) if (select_document_id or self.current_document_id) else None
        if target:
            for row in range(self.document_list.count()):
                if self.document_list.item(row).data(256) == target:
                    self.document_list.setCurrentRow(row)
                    break

    def on_project_selected(self) -> None:
        item = self.project_list.currentItem()
        if item is None:
            self.current_project_id = None
            return
        self.current_project_id = uuid.UUID(item.data(256))
        self.current_document_id = None
        self.reload_documents()
        self.clear_editor()

    def on_document_selected(self) -> None:
        item = self.document_list.currentItem()
        if item is None:
            return
        document_id = uuid.UUID(item.data(256))
        self.load_document(document_id)

    def clear_editor(self) -> None:
        self.current_document_id = None
        self.title_edit.clear()
        self.tags_edit.clear()
        self.category_edit.clear()
        self.editor.clear()
        self.info_label.setText("Документ не выбран")
        self.commit_list.clear()
        if hasattr(self, "branch_list"):
            self.branch_list.clear()
        self.is_dirty = False
        self._restore_save_button()

    def load_document(self, document_id: uuid.UUID) -> None:
        try:
            document = self.document_service.get_document(document_id)
            if document is None:
                raise ValueError("Документ не найден")
            self.current_document_id = document.id
            self.title_edit.blockSignals(True)
            self.tags_edit.blockSignals(True)
            self.category_edit.blockSignals(True)
            self.type_combo.blockSignals(True)
            self.editor.blockSignals(True)

            self.title_edit.setText(document.title)
            index = self.type_combo.findData(document.type)
            self.type_combo.setCurrentIndex(index if index >= 0 else 0)
            self.tags_edit.setText(document.tags)
            self.category_edit.setText(document.category)
            self.editor.setPlainText(document.content)

            self.title_edit.blockSignals(False)
            self.tags_edit.blockSignals(False)
            self.category_edit.blockSignals(False)
            self.type_combo.blockSignals(False)
            self.editor.blockSignals(False)
            self.is_dirty = False
            self.update_info(document)
            self.reload_commits()
            self.reload_branches()
            self._restore_save_button()
            self.set_status("Документ открыт")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка открытия документа", exc)

    def update_info(self, document: Document) -> None:
        self.info_label.setText(
            f"Название: {document.title}\n"
            f"Тип: {document.type}\n"
            f"Теги: {document.tags or '—'}\n"
            f"Категория: {document.category or '—'}\n"
            f"Создан: {document.created_at}\n"
            f"Изменён: {document.updated_at}"
        )

    def reload_commits(self) -> None:
        self.commit_list.clear()
        self.commits.clear()
        if self.current_document_id is None:
            return
        for commit in self.commit_service.list_commits(self.current_document_id)[:10]:
            item = QListWidgetItem(f"{commit.created_at:%H:%M:%S} — {commit.message}")
            item.setData(256, str(commit.id))
            self.commit_list.addItem(item)
            self.commits[str(commit.id)] = commit

    def reload_branches(self) -> None:
        if not hasattr(self, "branch_list"):
            return
        self.branch_list.clear()
        if self.current_document_id is None:
            return
        for branch in self.branch_service.list_branches(self.current_document_id):
            item = QListWidgetItem(f"{branch.name} · {branch.updated_at.replace('T', ' ')}")
            item.setData(256, branch.id)
            self.branch_list.addItem(item)

    def selected_branch_id(self) -> str | None:
        item = self.branch_list.currentItem() if hasattr(self, "branch_list") else None
        if item is None:
            return None
        return str(item.data(256))

    def selected_commit_id_from_panel(self) -> uuid.UUID | None:
        item = self.commit_list.currentItem()
        if item is None:
            return None
        return uuid.UUID(str(item.data(256)))

    def delete_selected_commit_from_panel(self) -> None:
        commit_id = self.selected_commit_id_from_panel()
        if commit_id is None:
            QMessageBox.information(self, "Коммит", "Выбери коммит в списке.")
            return
        if QMessageBox.question(self, "Удалить коммит", "Удалить выбранный коммит?") != QMessageBox.StandardButton.Yes:
            return
        try:
            self.commit_service.delete_commit(commit_id)
            self.reload_commits()
            self.set_status("Коммит удалён")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка удаления коммита", exc)

    def create_branch(self) -> None:
        if self.current_document_id is None:
            QMessageBox.information(self, "Ветка", "Сначала открой документ.")
            return
        if self.is_dirty:
            self.save_current_document()
        name, ok = QInputDialog.getText(self, "Новая ветка", "Название ветки:")
        if not ok or not name.strip():
            return
        try:
            branch = self.branch_service.create_branch(self.current_document_id, name.strip())
            self.reload_branches()
            self.set_status(f"Ветка создана: {branch.name}")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка создания ветки", exc)

    def save_branch_snapshot(self) -> None:
        branch_id = self.selected_branch_id()
        if branch_id is None:
            QMessageBox.information(self, "Ветка", "Выбери ветку.")
            return
        if self.is_dirty:
            self.save_current_document()
        try:
            branch = self.branch_service.save_current_to_branch(branch_id)
            self.reload_branches()
            self.set_status(f"Снимок сохранён в ветку: {branch.name}")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка сохранения ветки", exc)

    def checkout_branch(self) -> None:
        branch_id = self.selected_branch_id()
        if branch_id is None:
            QMessageBox.information(self, "Ветка", "Выбери ветку.")
            return
        if QMessageBox.question(self, "Переключить ветку", "Заменить текущий текст снимком ветки?") != QMessageBox.StandardButton.Yes:
            return
        try:
            branch = self.branch_service.checkout_branch(branch_id)
            self.load_document(uuid.UUID(branch.document_id))
            self.commit_service.create_commit(uuid.UUID(branch.document_id), f"Checkout branch {branch.name}")
            self.reload_commits()
            self.set_status(f"Переключено на ветку: {branch.name}")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка переключения ветки", exc)

    def delete_branch(self) -> None:
        branch_id = self.selected_branch_id()
        if branch_id is None:
            QMessageBox.information(self, "Ветка", "Выбери ветку.")
            return
        if QMessageBox.question(self, "Удалить ветку", "Удалить выбранную ветку?") != QMessageBox.StandardButton.Yes:
            return
        try:
            self.branch_service.delete_branch(branch_id)
            self.reload_branches()
            self.set_status("Ветка удалена")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка удаления ветки", exc)

    def mark_dirty(self) -> None:
        if self.current_document_id is not None:
            self.is_dirty = True
            self._restore_save_button()
            self.set_status("Есть несохранённые изменения")

    def _show_save_feedback(self, message: str) -> None:
        self.save_feedback_label.setText(f"✔ {message}")
        self.save_feedback_label.show()
        self.save_btn.setText(f"✔ {message}")
        self.save_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_DialogApplyButton))
        self.save_feedback_timer.start(2500)

    def _restore_save_button(self) -> None:
        self.save_feedback_label.hide()
        self.save_btn.setText("Сохранить")
        self.save_btn.setIcon(self._standard_icon(QStyle.StandardPixmap.SP_DialogSaveButton))

    def create_project(self) -> None:
        title, ok = QInputDialog.getText(self, "Новый проект", "Название проекта:")
        if not ok or not title.strip():
            return
        description, _ = QInputDialog.getMultiLineText(self, "Описание", "Описание проекта:")
        try:
            project = self.document_service.create_project(title, description)
            self.reload_projects()
            for row in range(self.project_list.count()):
                if self.project_list.item(row).data(256) == str(project.id):
                    self.project_list.setCurrentRow(row)
                    break
            self.set_status("Проект создан")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка создания проекта", exc)

    def require_project(self) -> bool:
        if self.current_project_id is None:
            QMessageBox.information(self, "Нужен проект", "Сначала создай или выбери проект.")
            return False
        return True

    def create_document(self) -> None:
        if not self.require_project():
            return
        dialog = NewDocumentDialog(self)
        if dialog.exec() != dialog.DialogCode.Accepted:
            return
        title, doc_type = dialog.values()
        try:
            document = self.document_service.create_document(self.current_project_id, title, doc_type)
            self.reload_documents(select_document_id=document.id)
            self.select_document(document.id)
            self.set_status("Документ создан")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка создания документа", exc)

    def select_document(self, document_id: uuid.UUID) -> None:
        for row in range(self.document_list.count()):
            if self.document_list.item(row).data(256) == str(document_id):
                self.document_list.setCurrentRow(row)
                return
        self.load_document(document_id)

    def save_current_document(self) -> bool:
        if self.current_document_id is None:
            QMessageBox.information(self, "Сохранение", "Сначала открой документ.")
            return False
        try:
            document = self.document_service.save_document(
                self.current_document_id,
                self.title_edit.text(),
                str(self.type_combo.currentData()),
                self.editor.toPlainText(),
                self.tags_edit.text(),
                self.category_edit.text(),
            )
            self.is_dirty = False
            self.update_info(document)
            self.reload_documents(select_document_id=document.id)
            self._show_save_feedback("Сохранено")
            self.set_status("Сохранено")
            return True
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка сохранения", exc)
            return False

    def save_as_file(self) -> None:
        if self.current_document_id is None:
            QMessageBox.information(self, "Сохранить как", "Сначала открой документ.")
            return
        raw_title = self.title_edit.text().strip() or "document"
        safe_title = re.sub(r'[\\/:*?"<>|]+', "_", raw_title)
        default_path = str(Path.home() / f"{safe_title}.md")
        path, selected_filter = QFileDialog.getSaveFileName(
            self,
            "Сохранить документ как",
            default_path,
            "Markdown (*.md);;Text file (*.txt);;Word DOCX (*.docx);;Word DOC (*.doc);;PDF (*.pdf)",
        )
        if not path:
            return

        export_path = Path(path)
        if export_path.suffix == "":
            if "Text file" in selected_filter:
                export_path = export_path.with_suffix(".txt")
            elif "Word DOCX" in selected_filter:
                export_path = export_path.with_suffix(".docx")
            elif "Word DOC" in selected_filter:
                export_path = export_path.with_suffix(".doc")
            elif "PDF" in selected_filter:
                export_path = export_path.with_suffix(".pdf")
            else:
                export_path = export_path.with_suffix(".md")

        title = self.title_edit.text().strip() or "Без названия"
        content = self.editor.toPlainText()

        try:
            if export_path.suffix.lower() == ".pdf":
                self._export_pdf(export_path, title, content)
            else:
                export_path = self.export_service.export_text(export_path, title, content)
            self._show_save_feedback("Экспортировано")
            self.set_status(f"Сохранено как: {export_path}")
        except ExportErrorForUser as exc:
            QMessageBox.warning(self, "Экспорт невозможен", str(exc))
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка 'Сохранить как'", exc)

    def _export_pdf(self, path: Path, title: str, content: str) -> None:
        document = QTextDocument()
        safe_title = title.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        safe_content = (
            content.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\n", "<br>")
        )
        document.setHtml(f"<h1>{safe_title}</h1><p>{safe_content}</p>")
        printer = QPrinter(QPrinter.PrinterMode.HighResolution)
        printer.setOutputFormat(QPrinter.OutputFormat.PdfFormat)
        printer.setOutputFileName(str(path))
        document.print(printer)

    def autosave(self) -> None:
        if not self.autosave_enabled or not self.is_dirty or self.current_document_id is None:
            return
        try:
            if self.save_current_document():
                from datetime import datetime

                self._show_save_feedback("Автосохранено")
                self.set_status(f"Автосохранено в {datetime.now():%H:%M:%S}")
        except Exception as exc:  # noqa: BLE001
            logger.exception("Autosave failed")
            QMessageBox.warning(self, "Автосохранение", f"Автосохранение не удалось: {exc}")

    def toggle_autosave(self) -> None:
        self.autosave_enabled = not self.autosave_enabled
        self.autosave_btn.setText(
            "Автосохранение: включено" if self.autosave_enabled else "Автосохранение: выключено"
        )
        self.user_settings.autosave_enabled = self.autosave_enabled
        self.settings_service.save(self.user_settings)
        self.set_status(self.autosave_btn.text())

    def import_document(self) -> None:
        if not self.require_project():
            return
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Импорт документа",
            str(Path.home()),
            "Documents (*.docx *.doc *.txt *.md *.markdown)",
        )
        if not path:
            return
        try:
            text = self.import_service.read_file_text(path)
            file_path = Path(path)
            document = self.document_service.create_document(
                self.current_project_id,
                file_path.stem,
                "note",
                text,
                tags="import",
                category="Импорт",
            )
            self.reload_documents(select_document_id=document.id)
            self.select_document(document.id)
            self.set_status("Документ импортирован")
        except ImportErrorForUser as exc:
            QMessageBox.warning(self, "Импорт невозможен", str(exc))
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка импорта", exc)

    def import_folder(self) -> None:
        if not self.require_project():
            return
        directory = QFileDialog.getExistingDirectory(self, "Импорт папки", str(Path.home()))
        if not directory:
            return
        try:
            files = self.import_service.list_importable_files(directory)
            if not files:
                QMessageBox.information(self, "Импорт папки", "В папке нет .txt, .md, .docx или .doc файлов.")
                return
            imported = 0
            errors: list[str] = []
            for file_path in files:
                try:
                    text = self.import_service.read_file_text(file_path)
                    rel_parent = file_path.parent.name
                    self.document_service.create_document(
                        self.current_project_id,
                        file_path.stem,
                        "note",
                        text,
                        tags="import, folder",
                        category=f"Импорт папки/{rel_parent}",
                    )
                    imported += 1
                except Exception as exc:  # noqa: BLE001
                    errors.append(f"{file_path.name}: {exc}")
            self.reload_documents()
            skipped = len(errors)
            message = f"Импортировано файлов: {imported}"
            if skipped:
                message += (
                    f"\nПропущено файлов: {skipped}\n\n"
                    "Некоторые файлы выглядят как .docx, но внутри не являются настоящими docx-файлами, "
                    "либо требуют LibreOffice/Word-конвертер. Программа не падает и продолжает импорт."
                )
            QMessageBox.information(self, "Импорт папки", message)
            self.set_status(f"Импортировано: {imported}; пропущено: {skipped}")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка импорта папки", exc)


    def create_commit(self) -> None:
        if self.current_document_id is None:
            QMessageBox.information(self, "Коммит", "Сначала открой документ.")
            return
        if self.is_dirty:
            self.save_current_document()
        dialog = CommitDialog(self)
        if dialog.exec() != dialog.DialogCode.Accepted:
            return
        try:
            commit = self.commit_service.create_commit(self.current_document_id, dialog.message())
            self.reload_commits()
            self.set_status(f"Коммит создан: {commit.message}")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка коммита", exc)

    def open_commit_history(self) -> None:
        if self.current_document_id is None:
            QMessageBox.information(self, "История", "Сначала открой документ.")
            return
        dialog = CommitHistoryDialog(self.current_document_id, self)
        result = dialog.exec()
        if result == dialog.DialogCode.Accepted:
            self.load_document(self.current_document_id)
        self.reload_commits()

    def open_concepts(self) -> None:
        if not self.require_project():
            return
        dialog = ConceptDialog(self.current_project_id, self)
        dialog.exec()
        self.reload_documents(select_document_id=self.current_document_id)

    def change_theme(self) -> None:
        name, ok = QInputDialog.getItem(self, "Тема", "Выбери тему:", theme_names(), 0, False)
        if not ok:
            return
        key = key_by_name(name)
        QApplication.instance().setStyleSheet(build_qss(key))
        self.user_settings = self.settings_service.update_theme(key)
        self.set_status(f"Тема применена и сохранена: {name}")

    def open_profile_settings(self) -> None:
        dialog = ProfileSettingsDialog(self)
        if dialog.exec() != dialog.DialogCode.Accepted:
            return
        value, account_id = dialog.values()
        if account_id:
            self.account_service.set_active(account_id)
            self.active_account = self.account_service.active_account()
        self.user_settings = self.settings_service.update_profile(
            value.profile_name,
            value.theme,
            value.autosave_enabled,
        )
        self.autosave_enabled = value.autosave_enabled
        self.autosave_btn.setText(
            "Автосохранение: включено" if self.autosave_enabled else "Автосохранение: выключено"
        )
        QApplication.instance().setStyleSheet(build_qss(value.theme))
        self.setWindowTitle(f"RedCord {__version__} — {self.active_account.display_name}")
        self.set_status("Профиль и настройки сохранены")

    def open_template_manager(self) -> None:
        dialog = TemplateManagerDialog(self)
        dialog.exec()
        current_type = self.type_combo.currentData()
        self.type_combo.blockSignals(True)
        self.type_combo.clear()
        for template_type, name in self.template_service.list_templates():
            self.type_combo.addItem(name, template_type)
        index = self.type_combo.findData(current_type)
        if index >= 0:
            self.type_combo.setCurrentIndex(index)
        self.type_combo.blockSignals(False)
        self.set_status("Типы документов обновлены")

    def search(self) -> None:
        query = self.search_edit.text().strip()
        self.search_list.clear()
        self.search_results.clear()
        if not query:
            return
        try:
            for document in self.search_service.search_documents(query, self.current_project_id):
                item = QListWidgetItem(f"{document.title} · {document.type} · {document.tags}")
                item.setData(256, str(document.id))
                self.search_list.addItem(item)
                self.search_results[str(document.id)] = document
            self.set_status(f"Найдено: {self.search_list.count()}")
        except Exception as exc:  # noqa: BLE001
            self.show_error("Ошибка поиска", exc)

    def open_search_result(self) -> None:
        item = self.search_list.currentItem()
        if item is None:
            return
        document_id = uuid.UUID(item.data(256))
        document = self.search_results.get(str(document_id))
        if document is not None:
            self.current_project_id = document.project_id
            self.reload_documents(select_document_id=document_id)
            self.select_document(document_id)
