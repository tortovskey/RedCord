@echo off
setlocal
cd /d "%~dp0.."

echo [BlueCord Lite] starting...

if not exist ".venv\Scripts\activate.bat" (
    echo [BlueCord] .venv not found.
    pause
    exit /b 1
)

call ".venv\Scripts\activate.bat"
python -m redcord.app.bluecord

if errorlevel 1 pause
endlocal
