from __future__ import annotations

import logging
import sys
from pathlib import Path

from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QApplication, QMessageBox

from redcord import __version__
from redcord.app.config import get_settings
from redcord.app.theme import build_qss
from redcord.db.database import check_database_connection, create_local_schema, init_engine
from redcord.services.settings_service import SettingsService
from redcord.services.template_service import TemplateService
from redcord.ui.main_window import MainWindow


def configure_logging() -> None:
    settings = get_settings()
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[
            logging.FileHandler(settings.log_file, encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
    )


def ensure_runtime_dirs() -> None:
    settings = get_settings()
    for path in [settings.data_dir, settings.commit_dir, settings.assets_dir]:
        Path(path).mkdir(parents=True, exist_ok=True)


def bootstrap() -> tuple[bool, str]:
    settings = get_settings()
    ensure_runtime_dirs()
    init_engine(settings.database_url)

    ok, error = check_database_connection(retries=3, delay_seconds=1.0)
    if not ok:
        return False, error

    try:
        if settings.uses_local_sqlite:
            create_local_schema()
        TemplateService().ensure_default_templates()
        SettingsService().load()
    except Exception as exc:  # noqa: BLE001
        logging.exception("Failed to bootstrap RedCord")
        return False, f"Не удалось подготовить данные приложения: {exc}"

    return True, "ok"


def _load_app_icon() -> QIcon:
    settings = get_settings()
    icon_path = settings.assets_dir / "redcord_icon.ico"
    if icon_path.exists():
        return QIcon(str(icon_path))
    png_fallback = settings.assets_dir / "redcord_icon.png"
    if png_fallback.exists():
        return QIcon(str(png_fallback))
    return QIcon()


def main() -> int:
    configure_logging()
    app = QApplication(sys.argv)
    app.setApplicationName("RedCord")
    app.setApplicationDisplayName(f"RedCord {__version__}")
    app.setWindowIcon(_load_app_icon())

    settings = get_settings()
    user_settings = SettingsService().load()
    app.setStyleSheet(build_qss(user_settings.theme or settings.default_theme))

    ok, message = bootstrap()
    if not ok:
        QMessageBox.critical(
            None,
            f"RedCord: ошибка запуска - RedCord {__version__}",
            message
            + "\n\nЕсли используешь PostgreSQL, проверь .env и миграции."
            + "\nЕсли запускаешь EXE без .env, RedCord должен создать локальную базу в папке data.",
        )
        logging.error("Startup failed: %s", message)
        return 1

    window = MainWindow()
    window.resize(1480, 880)
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
