from __future__ import annotations

import sys

from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QApplication, QMainWindow

from redcord import __version__
from redcord.app.config import get_settings
from redcord.app.theme import build_qss
from redcord.services.settings_service import SettingsService
from redcord.ui.widgets.bluecord_canvas import BlueCordWidget


def _load_icon() -> QIcon:
    settings = get_settings()
    icon = settings.assets_dir / "bluecord_icon.ico"
    if icon.exists():
        return QIcon(str(icon))
    png = settings.assets_dir / "bluecord_icon.png"
    return QIcon(str(png)) if png.exists() else QIcon()


def main() -> int:
    app = QApplication(sys.argv)
    settings = SettingsService().load()
    app.setApplicationName("BlueCord")
    app.setApplicationDisplayName("BlueCord v1")
    app.setWindowIcon(_load_icon())
    app.setStyleSheet(build_qss(settings.theme))
    window = QMainWindow()
    window.setWindowTitle(f"BlueCord v1 · BoC — RedCord {__version__}")
    window.setWindowIcon(_load_icon())
    window.setCentralWidget(BlueCordWidget())
    window.resize(1280, 820)
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
