@echo off
setlocal
cd /d "%~dp0.."

echo [BlueCord v1.0.1 / BoC] building Windows EXE...

if not exist ".venv\Scripts\activate.bat" (
    echo [BlueCord] .venv not found.
    pause
    exit /b 1
)

call ".venv\Scripts\activate.bat"
python -m pip install -r requirements.txt

if exist "bluecord_build" rmdir /s /q "bluecord_build"
if exist "build" rmdir /s /q "build"

pyinstaller --noconfirm --clean --distpath bluecord_build bluecord.spec

if errorlevel 1 (
    echo [BlueCord] Build failed.
    pause
    exit /b 1
)

if not exist "bluecord_build\BlueCord\BlueCord.exe" (
    echo [BlueCord] Build folder is missing BlueCord.exe
    pause
    exit /b 1
)

echo Output: bluecord_build\BlueCord\BlueCord.exe
pause
endlocal
