from __future__ import annotations

from pathlib import Path

from PyQt6.QtCore import QPoint, QRect, Qt
from PyQt6.QtGui import QColor, QImage, QMouseEvent, QPainter, QPen, QPixmap
from PyQt6.QtWidgets import (
    QColorDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QSlider,
    QVBoxLayout,
    QWidget,
)


class DrawingCanvas(QWidget):
    """Tiny raster canvas used by BlueCord."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setMinimumSize(820, 560)
        self.image = QImage(1600, 1000, QImage.Format.Format_RGB32)
        self.image.fill(QColor("white"))
        self.brush_color = QColor("#0f0b0d")
        self.brush_size = 6
        self.eraser_enabled = False
        self._drawing = False
        self._last_point = QPoint()

    def set_brush_size(self, value: int) -> None:
        self.brush_size = max(1, value)

    def set_color(self, color: QColor) -> None:
        self.brush_color = color
        self.eraser_enabled = False

    def set_eraser(self, enabled: bool) -> None:
        self.eraser_enabled = enabled

    def clear(self) -> None:
        self.image.fill(QColor("white"))
        self.update()

    def open_image(self, path: str | Path) -> bool:
        loaded = QImage(str(path))
        if loaded.isNull():
            return False
        self.image = loaded.convertToFormat(QImage.Format.Format_RGB32)
        self.setMinimumSize(min(max(self.image.width(), 820), 2000), min(max(self.image.height(), 560), 1600))
        self.update()
        return True

    def save_png(self, path: str | Path) -> bool:
        return self.image.save(str(path), "PNG")

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        target = QRect(0, 0, self.width(), self.height())
        painter.fillRect(target, QColor("#2b2b2b"))
        scaled = self.image.scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        x = (self.width() - scaled.width()) // 2
        y = (self.height() - scaled.height()) // 2
        painter.drawImage(x, y, scaled)

    def _map_to_image(self, point: QPoint) -> QPoint:
        scaled = self.image.scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        x_offset = (self.width() - scaled.width()) // 2
        y_offset = (self.height() - scaled.height()) // 2
        x = int((point.x() - x_offset) * self.image.width() / max(1, scaled.width()))
        y = int((point.y() - y_offset) * self.image.height() / max(1, scaled.height()))
        return QPoint(max(0, min(self.image.width() - 1, x)), max(0, min(self.image.height() - 1, y)))

    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self._drawing = True
            self._last_point = self._map_to_image(event.position().toPoint())

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if not self._drawing:
            return
        current = self._map_to_image(event.position().toPoint())
        painter = QPainter(self.image)
        color = QColor("white") if self.eraser_enabled else self.brush_color
        pen = QPen(color, self.brush_size, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
        painter.setPen(pen)
        painter.drawLine(self._last_point, current)
        self._last_point = current
        self.update()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self._drawing = False


class BlueCordWidget(QWidget):
    """Lite Krita-like drawing tab embedded into RedCord."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.canvas = DrawingCanvas()
        self.color_label = QLabel("Цвет")
        self.size_label = QLabel("Кисть: 6")

        self.color_btn = QPushButton("Цвет")
        self.eraser_btn = QPushButton("Ластик")
        self.eraser_btn.setCheckable(True)
        self.clear_btn = QPushButton("Очистить")
        self.open_btn = QPushButton("Открыть PNG/JPG")
        self.save_btn = QPushButton("Сохранить PNG")

        self.size_slider = QSlider(Qt.Orientation.Horizontal)
        self.size_slider.setMinimum(1)
        self.size_slider.setMaximum(64)
        self.size_slider.setValue(6)
        self.size_slider.setFixedWidth(180)

        self.color_btn.clicked.connect(self.pick_color)
        self.eraser_btn.toggled.connect(self.canvas.set_eraser)
        self.clear_btn.clicked.connect(self.clear_canvas)
        self.open_btn.clicked.connect(self.open_image)
        self.save_btn.clicked.connect(self.save_image)
        self.size_slider.valueChanged.connect(self.change_size)

        toolbar = QHBoxLayout()
        toolbar.addWidget(QLabel("BlueCord Lite"))
        toolbar.addWidget(self.color_btn)
        toolbar.addWidget(self.eraser_btn)
        toolbar.addWidget(self.size_label)
        toolbar.addWidget(self.size_slider)
        toolbar.addStretch(1)
        toolbar.addWidget(self.open_btn)
        toolbar.addWidget(self.save_btn)
        toolbar.addWidget(self.clear_btn)

        layout = QVBoxLayout(self)
        layout.addLayout(toolbar)
        layout.addWidget(self.canvas, 1)

    def pick_color(self) -> None:
        color = QColorDialog.getColor(self.canvas.brush_color, self, "Цвет кисти")
        if color.isValid():
            self.eraser_btn.setChecked(False)
            self.canvas.set_color(color)

    def change_size(self, value: int) -> None:
        self.canvas.set_brush_size(value)
        self.size_label.setText(f"Кисть: {value}")

    def clear_canvas(self) -> None:
        answer = QMessageBox.question(self, "BlueCord", "Очистить холст?")
        if answer == QMessageBox.StandardButton.Yes:
            self.canvas.clear()

    def open_image(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Открыть изображение", str(Path.home()), "Images (*.png *.jpg *.jpeg *.bmp)")
        if path and not self.canvas.open_image(path):
            QMessageBox.warning(self, "BlueCord", "Не удалось открыть изображение.")

    def save_image(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Сохранить рисунок", str(Path.home() / "bluecord_art.png"), "PNG (*.png)")
        if not path:
            return
        if Path(path).suffix.lower() != ".png":
            path += ".png"
        if not self.canvas.save_png(path):
            QMessageBox.warning(self, "BlueCord", "Не удалось сохранить PNG.")
