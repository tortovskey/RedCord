from __future__ import annotations

import logging
import sys
from pathlib import Path

from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QApplication, QMessageBox

from redcord import __version__
from redcord.app.config import get_settings
from redcord.app.theme import build_qss
from redcord.db.database import check_database_connection, init_engine
from redcord.services.template_service import TemplateService
from redcord.ui.main_window import MainWindow


def configure_logging() -> None:
    settings = get_settings()
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[
            logging.FileHandler(settings.log_file, encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
    )


def ensure_runtime_dirs() -> None:
    settings = get_settings()
    for path in [settings.commit_dir, settings.data_dir, settings.assets_dir, settings.data_dir / "templates"]:
        Path(path).mkdir(parents=True, exist_ok=True)


def bootstrap() -> tuple[bool, str]:
    settings = get_settings()
    if not settings.database_url:
        return (
            False,
            "DATABASE_URL не задан. Создай .env на основе .env.example и укажи подключение к PostgreSQL.",
        )

    ensure_runtime_dirs()
    init_engine(settings.database_url)

    ok, error = check_database_connection(retries=3, delay_seconds=1.0)
    if not ok:
        return False, error

    try:
        TemplateService().ensure_default_templates()
    except Exception as exc:  # noqa: BLE001
        logging.exception("Failed to ensure templates")
        return False, f"Не удалось подготовить шаблоны: {exc}"

    return True, "ok"


def _load_app_icon() -> QIcon:
    settings = get_settings()
    icon_path = settings.assets_dir / "redcord_icon.ico"
    if icon_path.exists():
        return QIcon(str(icon_path))
    png_fallback = settings.assets_dir / "redcord_icon.png"
    if png_fallback.exists():
        return QIcon(str(png_fallback))
    return QIcon()


def main() -> int:
    configure_logging()
    app = QApplication(sys.argv)
    app.setApplicationName("RedCord")
    app.setApplicationDisplayName(f"RedCord {__version__}")
    app.setWindowIcon(_load_app_icon())
    settings = get_settings()
    app.setStyleSheet(build_qss(settings.default_theme))

    ok, message = bootstrap()
    if not ok:
        QMessageBox.critical(
            None,
            "RedCord: ошибка запуска",
            message
            + "\n\nПроверь PostgreSQL, .env и миграции. Подробности записаны в redcord.log.",
        )
        logging.error("Startup failed: %s", message)
        return 1

    window = MainWindow()
    window.resize(1450, 850)
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
