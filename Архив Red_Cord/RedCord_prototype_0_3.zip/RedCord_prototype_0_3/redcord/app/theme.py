from __future__ import annotations

THEMES: dict[str, dict[str, str]] = {
    "dark_red": {
        "name": "Dark Red",
        "bg": "#0f0b0d",
        "panel": "#181214",
        "panel2": "#21181b",
        "text": "#f1e8ea",
        "muted": "#b8a7ab",
        "accent": "#8f1d2c",
        "accent2": "#b52a3b",
        "border": "#3a2429",
        "selection": "#5b1420",
        "success": "#8fe388",
    },
    "dark_green": {
        "name": "Dark Green",
        "bg": "#09100d",
        "panel": "#111b16",
        "panel2": "#17241d",
        "text": "#e8f2ed",
        "muted": "#9fb6aa",
        "accent": "#197146",
        "accent2": "#26a365",
        "border": "#20382b",
        "selection": "#12452d",
        "success": "#8fe388",
    },
    "dark_blue": {
        "name": "Dark Blue",
        "bg": "#090d14",
        "panel": "#111827",
        "panel2": "#172033",
        "text": "#e8edf7",
        "muted": "#9daecb",
        "accent": "#1f4f91",
        "accent2": "#2f75d6",
        "border": "#24324f",
        "selection": "#173969",
        "success": "#8fe388",
    },
}


def theme_names() -> list[str]:
    return [THEMES[key]["name"] for key in THEMES]


def key_by_name(name: str) -> str:
    for key, theme in THEMES.items():
        if theme["name"] == name:
            return key
    return "dark_red"


def build_qss(theme_key: str) -> str:
    t = THEMES.get(theme_key, THEMES["dark_red"])
    return f"""
    QWidget {{
        background: {t['bg']};
        color: {t['text']};
        font-family: "Segoe UI", Arial, sans-serif;
        font-size: 10.5pt;
    }}
    QMainWindow, QDialog {{ background: {t['bg']}; }}
    QFrame#Panel, QGroupBox {{
        background: {t['panel']};
        border: 1px solid {t['border']};
        border-radius: 12px;
    }}
    QLabel#TitleLabel {{
        color: {t['text']};
        font-size: 13pt;
        font-weight: 700;
    }}
    QLabel#MutedLabel {{ color: {t['muted']}; }}
    QLabel#SuccessLabel {{
        color: {t['success']};
        font-weight: 700;
        padding: 4px 8px;
        background: transparent;
    }}
    QPushButton {{
        background: {t['panel2']};
        border: 1px solid {t['border']};
        border-radius: 8px;
        padding: 7px 10px;
        color: {t['text']};
    }}
    QPushButton:hover {{
        background: {t['accent']};
        border-color: {t['accent2']};
    }}
    QPushButton:pressed {{ background: {t['selection']}; }}
    QPushButton#AccentButton {{
        background: {t['accent']};
        border-color: {t['accent2']};
        font-weight: 600;
    }}
    QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QListWidget {{
        background: {t['panel2']};
        border: 1px solid {t['border']};
        border-radius: 8px;
        padding: 6px;
        selection-background-color: {t['selection']};
        selection-color: {t['text']};
    }}
    QTextEdit {{ line-height: 130%; }}
    QListWidget::item {{
        padding: 6px;
        border-radius: 6px;
    }}
    QListWidget::item:selected {{
        background: {t['selection']};
        border-left: 3px solid {t['accent2']};
    }}
    QComboBox QAbstractItemView {{
        background: {t['panel2']};
        selection-background-color: {t['selection']};
    }}
    QStatusBar {{
        background: {t['panel']};
        color: {t['muted']};
    }}
    QSplitter::handle {{ background: {t['border']}; }}
    QScrollBar:vertical {{ background: {t['bg']}; width: 12px; }}
    QScrollBar::handle:vertical {{ background: {t['border']}; border-radius: 6px; }}
    QScrollBar::handle:vertical:hover {{ background: {t['accent']}; }}
    """
