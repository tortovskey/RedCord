# RedCord 0.4

RedCord — desktop-редактор для писателей на Python + PyQt6. Версия **0.4** чинит поведение EXE, добавляет локальный режим базы, профиль, сохранение настроек, новые темы и расширяет систему коммитов.

## Главное в 0.4

### EXE больше не обязан требовать `.env`

Если рядом с `RedCord.exe` нет `.env`, приложение автоматически создаёт локальную SQLite-базу:

```text
redcord_build/
  redcord/
    RedCord.exe
    data/
      redcord.db
      settings.json
      redcord.log
    commits/
```

PostgreSQL по-прежнему поддерживается. Для него достаточно положить `.env` рядом с `RedCord.exe` или в корень проекта.

### Папка сборки больше не `dist`

Сборка теперь идёт в:

```text
redcord_build/redcord/
```

а не в стандартную папку `dist/`.

### Новые темы

Теперь доступны:

- Dark Red
- Dark Green
- Dark Blue
- Dark
- White

### Профиль и настройки

Добавлена кнопка **Профиль / настройки**.

В настройках можно сохранить:

- имя профиля;
- тему;
- состояние автосохранения.

Настройки сохраняются в:

```text
data/settings.json
```

и применяются при следующем запуске.

### Коммиты стали ближе к Git-like арсеналу

В истории коммитов теперь можно:

- просматривать snapshot;
- откатываться к коммиту;
- изменять сообщение коммита;
- удалять коммит из БД;
- опционально удалять markdown-файл коммита.

## Установка для разработки

```powershell
cd C:\Users\user\Desktop\Codes\RedCord
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -U pip setuptools wheel
pip install -r requirements.txt
```

## Запуск в локальном SQLite-режиме

`.env` можно не создавать.

```powershell
python -m redcord.app.main
```

RedCord сам создаст:

```text
data/redcord.db
data/settings.json
commits/
```

## Запуск в PostgreSQL-режиме

Создай `.env`:

```powershell
copy .env.example .env
notepad .env
```

Пример:

```env
DATABASE_URL=postgresql+psycopg://postgres:1986@localhost:5432/record_db
APP_ENV=development
LOG_LEVEL=INFO
REDCORD_THEME=dark_red
COMMIT_DIR=./commits
DATA_DIR=./data
```

Создай базу:

```powershell
& "C:\Program Files\PostgreSQL\18\bin\psql.exe" -U postgres -h localhost -p 5432 -c "CREATE DATABASE record_db;"
```

Запусти миграции:

```powershell
.\.venv\Scripts\alembic.exe upgrade head
```

Запусти приложение:

```powershell
python -m redcord.app.main
```

## Сборка EXE

```powershell
scripts\build_exe.bat
```

Результат:

```text
redcord_build/redcord/RedCord.exe
```

Запуск:

```powershell
redcord_build\redcord\RedCord.exe
```

## Как проверить 0.4

### EXE без `.env`

1. Собери EXE через `scripts\build_exe.bat`.
2. Запусти `redcord_build\redcord\RedCord.exe`.
3. Приложение должно стартовать без ошибки `DATABASE_URL`.
4. Рядом появится папка `data` с `redcord.db`.

### Смена темы с сохранением

1. Открой **Профиль / настройки**.
2. Выбери `White` или `Dark`.
3. Закрой и снова открой приложение.
4. Тема должна сохраниться.

### Коммиты

1. Открой документ.
2. Создай коммит.
3. Открой **История коммитов**.
4. Проверь:
   - Просмотр;
   - Откатить;
   - Изменить сообщение;
   - Удалить коммит.

### Профиль

1. Открой **Профиль / настройки**.
2. Измени имя профиля.
3. Сохрани.
4. Проверь файл:

```text
data/settings.json
```

## Ограничения 0.4

- Локальный EXE-режим использует SQLite, а не PostgreSQL. Это сделано специально, чтобы приложение могло запускаться как обычная desktop-программа без настройки сервера.
- PostgreSQL остаётся основным режимом для курсовой/production-архитектуры.
- `.doc` импорт всё ещё зависит от LibreOffice, antiword или pypandoc.
- Веток как в настоящем Git пока нет. В 0.4 есть базовый арсенал: create, view, rollback, rename message, delete.
