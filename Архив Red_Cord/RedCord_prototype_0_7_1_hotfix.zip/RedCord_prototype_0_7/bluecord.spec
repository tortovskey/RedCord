# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path

project_root = Path.cwd()
assets_dir = project_root / "bluecord" / "assets"

a = Analysis(
    ["bluecord/app/main.py"],
    pathex=[str(project_root)],
    binaries=[],
    datas=[
        (str(assets_dir), "bluecord/assets"),
        (str(project_root / "README.md"), "."),
    ],
    hiddenimports=["PyQt6.sip"],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["redcord"],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="BlueCord",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    icon=str(assets_dir / "bluecord_icon.ico"),
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="BlueCord",
)
