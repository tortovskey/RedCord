from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[2]
load_dotenv(ROOT_DIR / ".env")


@dataclass(frozen=True)
class Settings:
    """Runtime settings loaded from .env or process environment."""

    database_url: str
    app_env: str
    log_level: str
    default_theme: str
    commit_dir: Path
    data_dir: Path
    assets_dir: Path
    log_file: Path


def _path_from_env(name: str, default: str) -> Path:
    raw = os.getenv(name, default)
    path = Path(raw)
    if not path.is_absolute():
        path = ROOT_DIR / path
    return path


def get_settings() -> Settings:
    database_url = os.getenv("DATABASE_URL", "").strip()
    return Settings(
        database_url=database_url,
        app_env=os.getenv("APP_ENV", "development"),
        log_level=os.getenv("LOG_LEVEL", "INFO"),
        default_theme=os.getenv("REDCORD_THEME", "dark_red"),
        commit_dir=_path_from_env("COMMIT_DIR", "./commits"),
        data_dir=_path_from_env("DATA_DIR", "./redcord/data"),
        assets_dir=_path_from_env("ASSETS_DIR", "./redcord/assets"),
        log_file=ROOT_DIR / "redcord.log",
    )
