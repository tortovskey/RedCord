# RedCord 0.7

RedCord — desktop-редактор для писателей на Python + PyQt6. Версия **0.7** добавляет self-healing/distributed-ready слой, BlueCord v1 и нормальный Windows installer через Inno Setup.

## Главное в 0.7

### Self-Healing / distributed-ready core

Добавлена отдельная вкладка **Self-Healing** и пакет:

```text
redcord/self_healing/
  retry_policy.py
  circuit_breaker.py
  health_checks.py
  recovery_manager.py
  outbox.py
  backup_service.py
  event_log.py
```

Реализованы базовые паттерны:

```text
✅ health checks
✅ retry-ready utility
✅ persistent circuit breaker
✅ graceful recovery manager
✅ outbox pattern для будущей синхронизации
✅ JSONL system event log
✅ backup service
✅ runtime folder repair
✅ диагностика data/, commits/, settings.json, outbox, database
```

Вкладка **Self-Healing** умеет:

- проверить здоровье системы;
- создать backup;
- выполнить repair;
- добавить тестовое outbox-событие;
- показать последние system events.

Это не полноценный серверный кластер, а desktop-ядро, подготовленное к будущей схеме:

```text
RedCord Desktop
Backend API
PostgreSQL / SQLite local cache
Background worker
Sync service
AI service
Outbox queue
```

### BlueCord v1 / BoC

BlueCord теперь обновлён до первой нормальной версии **v1**.

Добавлено:

```text
✅ голубая иконка BoC
✅ redcord/assets/bluecord_icon.ico
✅ redcord/assets/bluecord_icon.png
✅ redcord/assets/bluecord_icon.svg
✅ отдельный запуск BlueCord
✅ вкладка BlueCord внутри RedCord
```

Инструменты BlueCord v1:

```text
- Кисть
- Карандаш
- Ластик
- Линия
- Прямоугольник
- Эллипс
- Заливка
- Пипетка
- Текст
- Undo
- Redo
- Размер кисти
- Opacity
- Zoom
- Новый холст
- Открытие PNG/JPG/JPEG/BMP
- Сохранение PNG/JPG/BMP
```

Запуск отдельно:

```powershell
scripts\run_bluecord.bat
```

Сборка отдельно:

```powershell
scripts\build_bluecord.bat
```

### Нормальный установщик

Добавлен установщик через **Inno Setup 6**.

Файлы:

```text
installer/RedCord_Installer.iss
scripts/build_installer.bat
```

Установщик умеет:

```text
✅ установить RedCord
✅ опционально установить BlueCord standalone
✅ создать ярлыки
✅ не удалять пользовательские data/ и commits/
✅ использовать иконки RedCord и BlueCord
```

## Установка зависимостей

```powershell
cd C:\Users\user\Desktop\Codes\RedCord
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -U pip setuptools wheel
pip install -r requirements.txt
```

## Запуск из исходников

```powershell
python -m redcord.app.main
```

## Сборка RedCord EXE

```powershell
scripts\build_exe.bat
```

Результат:

```text
redcord_build/
  redcord/
    RedCord.exe
```

## Сборка BlueCord EXE

```powershell
scripts\build_bluecord.bat
```

Результат:

```text
bluecord_build/
  bluecord/
    BlueCord.exe
```

## Сборка установщика

Сначала установи **Inno Setup 6**.

Потом:

```powershell
scripts\build_installer.bat
```

Результат:

```text
installer_output/
  RedCord_Setup_0_7.exe
```

## Как проверить 0.7

1. Запусти RedCord.
2. Проверь вкладки:
   - Документы
   - Концепты
   - Git / версии
   - BlueCord
   - Self-Healing
   - Настройки
3. Перейди в **Self-Healing**.
4. Нажми **Проверить здоровье**.
5. Нажми **Создать backup**.
6. Нажми **Self-healing repair**.
7. Нажми **Тест outbox**.
8. Перейди в **BlueCord**.
9. Проверь кисть, карандаш, ластик, линию, прямоугольник, эллипс, заливку, пипетку, текст, undo/redo.
10. Сохрани изображение в PNG/JPG/BMP.
11. Собери EXE.
12. Собери установщик.

## Ограничения 0.7

- Self-healing пока локальный: это каркас для будущего распределённого режима, а не готовый облачный кластер.
- Outbox пока JSON-backed, без реального sync-сервера.
- Circuit breaker готов для внешних сервисов, но AI/backend ещё не подключены.
- BlueCord v1 — raster lite-редактор, без слоёв и PSD/KRA-форматов.
- Установщик требует установленный Inno Setup 6.
