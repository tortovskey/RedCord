@echo off
setlocal
cd /d "%~dp0.."

echo [RedCord 0.7] building full installer...

if not exist ".venv\Scripts\activate.bat" (
    echo [RedCord] .venv not found.
    echo Create it first:
    echo   py -3.12 -m venv .venv
    echo   .\.venv\Scripts\Activate.ps1
    echo   pip install -r requirements.txt
    pause
    exit /b 1
)

call ".venv\Scripts\activate.bat"
python -m pip install -r requirements.txt

if exist "redcord_build" rmdir /s /q "redcord_build"
if exist "bluecord_build" rmdir /s /q "bluecord_build"
if exist "build" rmdir /s /q "build"
if exist "installer_output" rmdir /s /q "installer_output"

echo [RedCord] Building RedCord.exe...
pyinstaller --noconfirm --clean --distpath redcord_build redcord.spec
if errorlevel 1 (
    echo [RedCord] RedCord build failed.
    pause
    exit /b 1
)

echo [RedCord] Building BlueCord.exe...
pyinstaller --noconfirm --clean --distpath bluecord_build bluecord.spec
if errorlevel 1 (
    echo [RedCord] BlueCord build failed.
    pause
    exit /b 1
)

set ISCC_EXE=
where ISCC.exe >nul 2>nul
if not errorlevel 1 set ISCC_EXE=ISCC.exe

if "%ISCC_EXE%"=="" if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set ISCC_EXE=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe
if "%ISCC_EXE%"=="" if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set ISCC_EXE=%ProgramFiles%\Inno Setup 6\ISCC.exe

if "%ISCC_EXE%"=="" (
    echo [RedCord] Inno Setup compiler not found.
    echo Install Inno Setup 6: https://jrsoftware.org/isinfo.php
    pause
    exit /b 1
)

echo [RedCord] Building installer...
"%ISCC_EXE%" installer\RedCord_Installer.iss
if errorlevel 1 (
    echo [RedCord] Installer build failed.
    pause
    exit /b 1
)

echo.
echo [RedCord] Installer complete:
echo   installer_output\RedCord_Setup_0_7.exe
pause
endlocal
