from __future__ import annotations

from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLineEdit,
    QLabel,
    QVBoxLayout,
)

from redcord.app.theme import key_by_name, theme_names, display_name_by_key
from redcord.services.settings_service import SettingsService, UserSettings


class ProfileSettingsDialog(QDialog):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Профиль и настройки")
        self.resize(420, 220)

        self.service = SettingsService()
        self.current = self.service.load()

        self.name_edit = QLineEdit(self.current.profile_name)
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(theme_names())
        self.theme_combo.setCurrentText(display_name_by_key(self.current.theme))
        self.autosave_checkbox = QCheckBox("Включить автосохранение")
        self.autosave_checkbox.setChecked(self.current.autosave_enabled)

        hint = QLabel(
            "Настройки сохраняются в data/settings.json и применяются при следующем запуске."
        )
        hint.setWordWrap(True)
        hint.setObjectName("MutedLabel")

        form = QFormLayout()
        form.addRow("Имя профиля", self.name_edit)
        form.addRow("Тема", self.theme_combo)
        form.addRow("", self.autosave_checkbox)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addWidget(hint)
        layout.addLayout(form)
        layout.addWidget(buttons)

    def values(self) -> UserSettings:
        return UserSettings(
            profile_name=self.name_edit.text().strip() or "Автор",
            theme=key_by_name(self.theme_combo.currentText()),
            autosave_enabled=self.autosave_checkbox.isChecked(),
        )
