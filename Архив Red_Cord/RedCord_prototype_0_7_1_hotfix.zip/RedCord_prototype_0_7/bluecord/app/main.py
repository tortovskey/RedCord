from __future__ import annotations

import sys
from pathlib import Path

from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QApplication, QMainWindow

from bluecord import __version__
from bluecord.widgets.canvas import BlueCordWidget


def app_dir() -> Path:
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[2])).resolve()


def load_icon() -> QIcon:
    root = app_dir()
    for path in [
        root / "bluecord" / "assets" / "bluecord_icon.ico",
        root / "bluecord" / "assets" / "bluecord_icon.png",
        Path(sys.executable).resolve().parent / "bluecord" / "assets" / "bluecord_icon.ico",
        Path(sys.executable).resolve().parent / "bluecord" / "assets" / "bluecord_icon.png",
    ]:
        if path.exists():
            return QIcon(str(path))
    return QIcon()


def qss() -> str:
    return """
    QWidget {
        background: #071522;
        color: #e8f5ff;
        font-family: "Segoe UI", Arial, sans-serif;
        font-size: 10.5pt;
    }
    QMainWindow {
        background: #071522;
    }
    QPushButton, QComboBox {
        background: #10263a;
        border: 1px solid #1f5c8a;
        border-radius: 8px;
        padding: 7px 10px;
        color: #e8f5ff;
    }
    QPushButton:hover, QComboBox:hover {
        background: #0c5cff;
        border-color: #4fc3ff;
    }
    QLabel {
        background: transparent;
        color: #e8f5ff;
    }
    QSlider::groove:horizontal {
        height: 6px;
        background: #16344f;
        border-radius: 3px;
    }
    QSlider::handle:horizontal {
        width: 14px;
        background: #4fc3ff;
        border-radius: 7px;
        margin: -5px 0;
    }
    """


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("BlueCord")
    app.setApplicationDisplayName(f"BlueCord {__version__} · BoC")
    app.setWindowIcon(load_icon())
    app.setStyleSheet(qss())

    window = QMainWindow()
    window.setWindowTitle(f"BlueCord {__version__} · BoC")
    window.setWindowIcon(load_icon())
    window.setCentralWidget(BlueCordWidget())
    window.resize(1280, 820)
    window.show()

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
